## Review: Controller dispatch refactor

The whitelist of controller names is a good change. Several behavioral regressions are more serious, though, and I would not merge this as written.

### Issues

**1. High: `is_callable()` alone reintroduces the Smarty `__call` bug (`dispatch()`, action check).**
The removed code had an explicit comment: Smarty 4 uses `__call` internally, so `is_callable()` always returns true, and `method_exists()` must also be checked. The new code uses only `is_callable([$controllerObj, $actionMethod])` and `is_callable([$controllerObj, $processMethod])`. A request for a nonexistent action will now reach Smarty's `__call` instead of the "action does not exist" path. Restore the `method_exists()` checks.

**2. High: Argument passing is order-dependent, contradicting the stated design (`dispatch()`).**
The docblock says routing is "order-independent," but `$args` is built from the query params in URL order and passed with `...array_values($args)`. A URL such as `controller=document&action=view&doc_id=456&patient_id=123` will pass `doc_id` as the first positional argument, whatever the action signature expects. Either map arguments by name, or document that order still matters.

**3. High: `_state` check changed from loose to strict comparison (`dispatch()`).**
The original code used `$c_obj->_state == false`. The new code uses `=== false`. If `_state` defaults to `null` or another falsy value, the process action no longer short-circuits, and the main action runs after a failed process step. Restore loose comparison or confirm the default is always `false`.

**4. Medium: Missing-argument behavior changed.**
The old code passed `null` for every expected argument missing from the request. The new code only passes what is in the URL. An action with required parameters will now throw `ArgumentCountError` when a parameter is absent, where it previously received `null`. The empty-value handling also changed: the old `empty() && != "0"` check became `=== ''`, so values such as `[]` or `false` now pass through unchanged.

**5. Medium: Process-without-action path throws a raw `Error` (`dispatch()`).**
If `$isProcessing` is true but `$actionMethod` does not exist, the code calls `$callMethod($actionMethod)` without checking. The result is a PHP `Error` ("Call to undefined method"), not the intended `NotFoundHttpException`. The same `method_exists` fix as in item 1 resolves this.

**6. Medium: Exceptions replace the old output-and-exit behavior.**
The old code echoed a message and called `exit`. The new code throws `BadRequestHttpException` and `NotFoundHttpException`. This is only safe if the front controller catches these and renders an HTTP error. Otherwise users get an unhandled 500, and the controller file-load failure behavior changes too. Confirm the caller handles these exceptions.

**7. Low: Global side effects in `dispatch()`.**
`unset($_GET['process'])` and `$_POST['process'] = "true"` modify superglobals even though `dispatch()` takes an explicit `$params` array. This makes `dispatch()` harder to test and reason about. Only the `$params` copy should be changed, and `$_POST` should be set deliberately by the caller.

**8. Low: `act()` on an empty array.**
`act()` is typed to require a non-empty array, but `$keys[0]` on an empty array emits a warning and casts `null` to `""`. Guard against this explicitly and throw a clear error.

**9. Low: Return coercion hides errors.**
`$callMethod` converts any non-string action return value to `''`. A controller that accidentally returns `null` or an array will produce empty output with no log entry. Consider logging or throwing.

**10. Low: No tests in the diff.**
The routing logic has changed substantially (argument handling, ACL, process flow, exceptions), and no tests accompany it. Add coverage for the whitelist, the process flow, missing actions, and argument passing before merging.

### Summary

Items 1 through 3 are regressions that could break production behavior, so they should block the merge. Items 4 and 6 need confirmation or an explicit decision. The rest are cleanup and test coverage.