## Review Comments

**Location:** `src/Services/Cda/XmlExtended.php`, both `open()` and `XML()` calls

**Issue:** Removal of `LIBXML_XINCLUDE` flag

This is a significant behavioral change that isn't explained in the diff. A few concerns:

1. **Correctness/Reliability (Medium-High):** If any CDA documents being parsed rely on `<xi:include>` elements to pull in external content, this change will silently break that functionality — includes will no longer be resolved, and the XML will be processed as-is with the `xi:include` tags left unprocessed (or ignored) rather than expanded. This could cause missing data in processed documents without any obvious error.

2. **Security (worth confirming, not necessarily a problem):** `LIBXML_XINCLUDE` is sometimes a security concern because it can be leveraged for XXE-style local file disclosure if an attacker controls the XML content and can inject `xi:include` with `parse="text"` pointing at arbitrary files. If that's the motivation for this change, it's a reasonable hardening step — but the PR gives no indication of *why* this was removed. Given this class already deals with externally-sourced/uploaded CDA documents (per `$this->directory = dirname($filename)` usage elsewhere for resolving relative hrefs), removing XInclude could be a deliberate security fix, but it should be called out explicitly.

3. **Maintainability (Medium):** There's no comment or commit message context explaining the rationale. A future maintainer (or this reviewer) can't tell if this was intentional hardening, an accidental side effect of unrelated changes, or a bug fix for a different issue (e.g., XInclude causing parsing failures/hangs on huge files in combination with `LIBXML_PARSEHUGE`). This ambiguity should be resolved before merging — the PR description/commit message should state why XInclude support is being dropped and confirm it's not depended upon by any CDA templates/processing logic.

4. **Testing gap (Medium):** There don't appear to be any tests included in the diff validating that CDA documents using XInclude still work (or are expected not to). If any sample/test CDA documents use `xi:include`, this change should have accompanying test coverage demonstrating the new expected behavior.

**Recommendation:** Request clarification/justification in the PR description. If this is a deliberate XXE-hardening measure, it should be stated as such, and ideally paired with a check for whether any current document processing relies on XInclude (so as not to silently break production imports). If it's incidental, it should be reverted or discussed separately.

---

No other issues found in the diff itself (the `CdaValidateDocuments.php` file is provided for context only and is unchanged).