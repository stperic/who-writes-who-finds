## Review Comments

**Location:** `interface/billing/get_claim_file.php`, new ACL check block

**Issue 1 — Overly permissive ACL check for file access (Correctness/Security, Medium-High)**
The check uses `'write'` as the `$return_value` for both `acct/eob` and `acct/bill`. Looking at `aclCheckCore`, passing a non-empty `$return_value` means the function only grants access if there's an explicit ACL entry with `return_value == 'write'`. Depending on how roles are configured in this system, users who only have "view" (non-write) access to billing/EOB may be unable to view/download claim files that they should reasonably be able to see (this is a retrieval endpoint, not a mutation). Conversely, if the intent was "any access to billing is enough to view a claim file," requiring `write` specifically may be too restrictive for legitimate read-only billing users, or if that's not actually the intent, it could be a correctness bug (should this require only view access, not write?). Reviewer should confirm business requirement: should read-only billing/EOB staff be able to download claim files? If yes, this is a functional regression/bug — users with only read access get denied. If the intent is strictly write access controls file downloads, that seems like a mismatched permission model for a read-only `get_*` action.

**Severity:** Medium — this is a logic/requirements correctness issue that could lock out legitimate users or, if reversed, overshare data. Needs confirmation of intended ACL semantics.

---

**Issue 2 — Ordering of ACL check vs. CSRF check is fine, but no major issue; it's just worth noting**
The ACL check correctly happens before CSRF validation, which is appropriate (authorization before token verification). No issue here, just confirming order is logical — denying access early is fine since `AccessDeniedHelper::denyWithTemplate` presumably exits/terminates execution. Reviewer should verify this function actually halts execution (via `exit`/`die`) rather than merely rendering a template and continuing, since if it does not terminate, the code below (CSRF check and whatever follows) will still execute even though access was denied.

**Severity:** Medium (verify the behavior of `denyWithTemplate`; this is a reliability/security risk if it doesn't terminate script execution — the diff doesn't show an explicit `exit`/`die`/`return` after the call).

---

**Issue 3 — Hardcoded English string in the first argument to `denyWithTemplate` (Maintainability, Low)**
The first argument `"ACL check failed for acct/eob or acct/bill: Billing Manager"` appears to be a log/debug message (not wrapped in `xl()`), which is fine if it's only used for logging, but worth confirming this isn't shown to the user untranslated. If it is user facing, it should be internationalized like the second argument.

**Severity:** Low

---

**Issue 4 — No test coverage for the new ACL enforcement**
The diff adds a new security control with no accompanying unit/integration test verifying that unauthorized users are denied and authorized users are allowed. Given this is a security-sensitive change, lack of tests is a maintainability/reliability concern.

**Severity:** Low-Medium