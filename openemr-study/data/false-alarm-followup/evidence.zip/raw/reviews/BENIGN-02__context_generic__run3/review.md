## Review of `XmlExtended.php` diff

**Location:** `src/Services/Cda/XmlExtended.php`, both `open()` and `XML()` calls

**Change:** Removes `LIBXML_XINCLUDE` from the libxml option flags used when parsing CDA documents via `XMLReader`.

### Issues

1. **Correctness / Behavior change (Medium-High)**
   Removing `LIBXML_XINCLUDE` disables automatic processing of `<xi:include>` elements. If any CDA/CCDA documents processed by this reader rely on XInclude directives (not uncommon in some CDA tooling/templates for including fragments), those includes will now be silently left unresolved (the `xi:include` elements will just appear as literal nodes instead of being replaced by their referenced content). This could cause silent data loss or malformed parsing results in production without any error being raised. Reviewer should confirm whether CDA documents processed here are ever expected to use XInclude; if so, this is a functional regression.

   - If this change is intentional (e.g., XInclude was identified as an XXE-adjacent attack vector allowing inclusion of arbitrary local/remote files), it's actually a **security hardening fix** rather than a regression — but the PR description/commit message doesn't clarify intent, and there's no code comment explaining why this flag was removed. **This ambiguity itself is a maintainability issue.**

2. **Missing justification / comment (Low-Medium)**
   No comment or changelog note explains *why* `LIBXML_XINCLUDE` was removed. Given this affects two separate code paths (`open()` from file and `XML()` from string), future maintainers (or the author in six months) won't know whether this was deliberate security hardening (XInclude can be used for local file disclosure/SSRF-like attacks, similar to XXE) or an accidental behavioral regression. A code comment or PR description should state the rationale.

3. **No accompanying test coverage change (Medium)**
   There are no tests included (or referenced) that verify documents without XInclude still parse correctly, nor any test that confirms previously-exploitable XInclude-based attacks are now blocked. If the goal is security hardening, a regression test demonstrating that XInclude is no longer processed (e.g., parsing a crafted document that attempts to include `file:///etc/passwd` and asserting it's not resolved) would be valuable and should be added.

4. **Inconsistent entity/XXE hardening elsewhere (Informational, Low)**
   Note that `CdaValidateDocuments::validateXmlXsd()` uses `DOMDocument::loadXML()` without explicitly disabling external entity loading and without `LIBXML_NOENT`/`libxml_disable_entity_loader` protections. While `libxml_disable_entity_loader` is deprecated/removed in newer PHP, if XInclude was removed from `XmlExtended` for security reasons, it would be worth auditing other XML parsing entry points (like this `DOMDocument::loadXML` call) for consistent XXE/external-entity protections, since CDA documents are often user/externally supplied. Not a defect introduced by this diff, but worth flagging given the apparent security motivation.

### Summary
The diff itself is a one-line removal of a flag in two places. The main risk is that this is a **behavioral change with unclear intent and no documentation or tests**, which could either:
- silently break parsing of legitimate documents containing XInclude references (functional regression), or
- be an intentional security fix against XInclude-based XXE/file-disclosure attacks (good, but needs stating and testing).

**Severity:** Medium — the change is small but has real security/correctness implications depending on intent, and currently ships with no explanation, no tests, and no indication the behavior change was deliberate and verified against real-world CDA samples that might use `xi:include`.