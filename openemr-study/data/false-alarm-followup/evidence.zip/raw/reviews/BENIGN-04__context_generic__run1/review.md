## Review Summary

This is a good security fix — it replaces unsafe string concatenation (which could allow JS injection via single quotes or `</script>` breakout) with proper JSON-based escaping via `js_escape()`. Since `json_encode()` escapes quotes, backslashes, control characters, and by default escapes forward slashes (`/` → `\/`), this also mitigates `</script>` breakout attacks. Overall the change is correct and should be approved, but a few points are worth flagging.

---

### 1. Dependency on `js_escape()` being defined/included
**Location:** `portal/portal_payment.php`, new line using `js_escape(...)`
**Problem:** `js_escape()` is defined in `library/htmlspecialchars.inc.php`. The diff doesn't show whether this file (or a bootstrap file that includes it, e.g. `globals.php`) is already required in `portal_payment.php`. If it isn't reliably included in this portal context, this will trigger a fatal "call to undefined function" error.
**Severity:** Medium (reliability) — easy to verify, but worth confirming before merge since portal pages sometimes have a different bootstrap/include chain than the main app.

---

### 2. Behavioral edge case when fields are `null`
**Location:** Same line
**Problem:** Previously, if `$edata['table_args']` or `$edata['checksum']` were `null`, string concatenation would silently coerce them to an empty string, producing `var jsondata='';`. Now, `js_escape(null)` → `json_encode(null)` returns the literal string `null` (no quotes), producing `var jsondata=null;` instead of a quoted empty string. If any downstream JS code assumes `jsondata`/`ccdata` are always strings (e.g., calls `.length` or string methods directly instead of using `JSON.parse`), this could cause a runtime difference between old and new behavior.
**Severity:** Low — edge case, but worth a quick check of the front-end consumer code to ensure it handles `null` gracefully (e.g., via `JSON.parse`, which does handle `"null"` → `null` safely).

---

### 3. (Pre-existing, not introduced by this diff) Exposing raw ciphertext/checksum to the client
**Location:** `$edata['checksum']` is embedded into the page as `ccdata` without decryption, while a decrypted copy (`$ccdata`) is computed server-side but unused in this snippet.
**Problem:** This isn't a new issue (the same value was already being emitted before this PR), but since this hunk touches that exact line, it may be worth a reviewer sanity-check on whether exposing the encrypted checksum string to client-side JS is intentional and doesn't leak more than necessary.
**Severity:** Informational/Low — out of scope for this PR's fix, but flagged for awareness since the PR touches this line.

---

### Overall
The core change (switching to `json_encode`-based `js_escape()`) is the right fix for the XSS risk from the original single-quote string interpolation, and no new vulnerability is introduced. Main action items before merge: confirm `js_escape()` is available in this file's include chain, and double check null-handling on the JS consumer side.