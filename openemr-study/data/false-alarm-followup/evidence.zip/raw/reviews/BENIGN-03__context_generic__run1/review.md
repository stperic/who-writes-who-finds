**Review comments**

1. **Location:** `interface/billing/get_claim_file.php`, new ACL check block.
   **Issue:** The ACL check requires `write` access on either `acct/eob` or `acct/bill`, but this endpoint's purpose (per its name) appears to be *retrieving/reading* a claim file, not writing one. Requiring `write` permission may be overly restrictive and block users who should have read-only access to view claim files (e.g., billing staff with view-only rights), or conversely, if `write` is too loose a proxy, it may not correctly restrict file access to only those who should see it. The access level requested should be re-examined against the actual operation performed by this script (serving/downloading a file).
   **Severity:** Medium — potential functional/security correctness issue; needs confirmation against actual endpoint behavior.

2. **Location:** `interface/billing/get_claim_file.php`, placement of the ACL check relative to CSRF check.
   **Issue:** The ACL check is placed before the CSRF check, which is fine, but there's no verification that the ACL check happens *before* any file path parameters are read/processed further down (not shown in diff). If downstream code uses `$_GET` or `$_REQUEST` parameters to build file paths, ensure this new check doesn't just gate access without also validating that the acting user is authorized for the *specific* claim/patient being requested — ACL checks like this are coarse-grained (user has billing permission generally) and don't verify the user has rights to this particular patient's claim data. This could still allow horizontal privilege escalation (any billing user accessing any patient's claim file) if no patient-level check exists elsewhere in the file.
   **Severity:** Medium-High — depends on whether further patient-specific authorization exists later in the file (not shown); worth confirming in the full file.

3. **Location:** `AccessDeniedHelper::denyWithTemplate` call.
   **Issue:** The first argument `"ACL check failed for acct/eob or acct/bill: Billing Manager"` is a hardcoded, non-translated string that will presumably be logged or displayed. It's inconsistent with the `xl()`-wrapped second argument. If this string is user-facing, it should also be wrapped in `xl()` for translation; if it's only for internal logging, this is fine but should be clarified/documented.
   **Severity:** Low — minor i18n/maintainability nit, not functionally breaking.

4. **Location:** Use of `AclMain::aclCheckCore` directly instead of a higher-level helper.
   **Issue:** Minor consistency concern: other parts of the codebase typically use `AclMain::aclCheckAcoSpec` or similar wrapper. Using `aclCheckCore` directly duplicates the OR-of-two-ACOs logic inline rather than leveraging existing abstractions (e.g., passing an array of ACO specs). Not a bug, but a maintainability note — if this access pattern (`acct|eob` OR `acct|bill` write) is used elsewhere, it should be centralized rather than repeated.
   **Severity:** Low.

5. **General observation:** No issue with the overall intent — adding this ACL check is a good and important security fix (previously only CSRF was being verified, meaning any authenticated user could potentially fetch arbitrary claim files via CSRF-protected but ACL-unprotected endpoint). This is a positive change; my comments are refinements rather than objections to the overall patch.