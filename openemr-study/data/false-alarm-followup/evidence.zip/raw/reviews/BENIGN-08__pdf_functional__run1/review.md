## Review of `Recorder.php` diff

### 1. Pre-existing race condition in sequence number generation (not fixed by this change)
- **Location:** `getNextSequenceNumber()`, `SELECT IFNULL(MAX(sequence_no),0)+1 ... FROM ar_activity WHERE pid = ? AND encounter = ?`
- **OWASP Category:** A04:2021 – Insecure Design / A08:2021 – Software and Data Integrity Failures
- **Problem:** The method itself documents a known TOCTOU race: two concurrent requests for the same patient/encounter can read the same `MAX(sequence_no)` and then both insert with the same `sequence_no+1`, producing duplicate or colliding sequence numbers in a financial ledger table (`ar_activity`). This change only hardens the *parsing* of the result, it does not address the underlying concurrency flaw. In a payment-processing context, this can cause duplicate/overwritten billing activity rows or inconsistent ledgers, which is a data-integrity issue with financial impact.
- **Severity:** Medium–High (financial data integrity; exploitable under concurrent requests, no authentication bypass required, but requires ability to trigger concurrent writes, e.g., double-submission or automated requests).
- **Recommendation:** Use a locking read (`SELECT ... FOR UPDATE`) inside the existing transaction, or compute the next sequence number as part of the INSERT via a subquery with a unique constraint, as the original comment suggests.

### 2. Unhandled exception may cause uncontrolled failure / information disclosure
- **Location:** New `throw new \RuntimeException(...)` in `getNextSequenceNumber()`
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures / A05:2021 – Security Misconfiguration (minor)
- **Problem:** The new validation is a good defensive improvement (previously a `null`/non-numeric `increment` would have been silently used, which is worse), but it's unclear whether callers catch this exception. If uncaught, this could propagate to a generic error handler and potentially leak a stack trace or internal query details depending on the app's error-display configuration. There is also no logging call here, so repeated failures (which could indicate DB corruption or tampering) won't be captured for monitoring.
- **Severity:** Low (depends entirely on global error-handling/display_errors configuration, which this diff doesn't control, but it's worth verifying).
- **Recommendation:** Ensure the global exception handler logs this condition and never echoes exception details/stack traces to the client; consider adding an explicit log entry before throwing since this indicates abnormal DB state in a payment-critical path.

### 3. SQL injection — not an issue here (verified safe)
- **Location:** `QueryUtils::querySingleRow(<<<'SQL' ... SQL, [$patientId, $encounterId])`
- **OWASP Category:** A03:2021 – Injection
- **Problem:** None — query uses parameterized placeholders (`?`) with bound parameters, not string concatenation. No action needed.

### 4. Type/return-value change itself
- The change from `string` to `int` and the added numeric validation is a positive security/robustness improvement — it prevents a `null`/non-numeric value from silently flowing into a financial record as a sequence number, which previously could have caused NULL/empty `sequence_no` inserts (an integrity problem). No new vulnerability introduced here.

---

### Out of scope / no evidence in diff
The "Approved PDF export requirement" note does not correspond to any code in this diff (no PDF-generation, image-handling, or export code is shown), so no findings can be made against it from this patch. If a PDF-export code path exists elsewhere, it should be reviewed separately for XSS (narrative content rendered unescaped into PDF/HTML), path traversal/SSRF (image loading by URL/path), and access control (ensuring only authorized clinical staff for the correct patient can export).

### Summary
No new injection, authentication, or access-control vulnerabilities are introduced by this diff. The main concerns are:
1. The long-standing, self-documented race condition in sequence-number generation (Medium–High, financial data integrity) — not addressed by this patch.
2. Minor concern about exception handling/logging for the new failure path (Low).