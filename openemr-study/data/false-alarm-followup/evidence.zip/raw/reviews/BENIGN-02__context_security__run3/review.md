# Security Review

## Summary of the Diff

The actual change is small: it removes the `LIBXML_XINCLUDE` flag from two `XMLReader` calls in `XmlExtended.php`. This is a **positive security fix**, not a vulnerability introduction.

### Finding 1 (Positive change — not a vulnerability)
- **Location:** `src/Services/Cda/XmlExtended.php`, both modified lines
- **OWASP Category:** A05:2021 – Security Misconfiguration / A03:2021 – Injection (XXE-adjacent)
- **Detail:** `LIBXML_XINCLUDE` enables automatic processing of `<xi:include>` elements in XML, which allows an attacker-supplied XML document to pull in arbitrary local files (via `file://`) or remote resources (via `http://`), leading to local file disclosure or SSRF-like behavior, even when classic external entity (XXE) loading is otherwise disabled. Removing this flag closes that vector.
- **Severity:** This fix reduces risk that was previously **High/Critical** (XInclude-based file disclosure / SSRF). Good catch — no further action needed here.

However, I'd flag two residual concerns in this same file/area:

### Finding 2 — Residual XXE risk not fully addressed
- **Location:** `src/Services/Cda/XmlExtended.php` (both `open()` and `XML()` calls)
- **OWASP Category:** A05:2021 – Security Misconfiguration (classic XXE, CWE-611)
- **Problem:** Removing `LIBXML_XINCLUDE` mitigates XInclude-based inclusion, but does not address classic external entity expansion via `<!DOCTYPE ... SYSTEM "...">` / `<!ENTITY ... SYSTEM "...">` declarations. Whether this is currently safe depends on PHP version/libxml defaults:
  - In PHP < 8.0, `libxml_disable_entity_loader()` must be explicitly set to prevent external entity loading; if it's not called anywhere in the pipeline, DTD-based XXE is still possible.
  - Even in PHP ≥ 8.0 (where entity substitution is disabled by default for `simplexml`/`DOMDocument` via `loadXML`), **`XMLReader`** behavior should be explicitly verified — `LIBXML_NOENT` is not set here so entities aren't substituted, but DOCTYPE processing and external DTD fetching could still occur unless `LIBXML_DTDLOAD`/`LIBXML_DTDATTR` are absent and the libxml default is confirmed safe. The code does not explicitly disable DTD loading (e.g., no `LIBXML_NONET`, no explicit disabling of external entities).
  - Neither call sets `LIBXML_NONET`, so if DTDs or external entities are referenced, libxml could still attempt network/file access depending on libxml version defaults.
- **Severity:** Medium–High (depends on PHP/libxml version in production; should be explicitly verified and hardened rather than relying on version-dependent defaults).
- **Recommendation:** Explicitly add `LIBXML_NONET` to the flags, and confirm `libxml_disable_entity_loader(true)` is set for PHP versions where it matters, or otherwise verify that `XMLReader` with these flags cannot resolve external DTDs/entities. Add a regression test with a malicious CDA document containing `<!DOCTYPE foo SYSTEM "http://attacker/...">` and `<!ENTITY xxe SYSTEM "file:///etc/passwd">` to confirm no disclosure.

## Pre-existing Issues in Touched/Related Code (`CdaValidateDocuments.php`)

Since this file is closely related (consumes XML parsed via similar XMLReader/DOMDocument paths) and was provided as context, the following pre-existing issues are worth flagging even though not modified by this diff:

### Finding 3 — XXE in `validateXmlXsd`
- **Location:** `CdaValidateDocuments.php::validateXmlXsd()` — `$dom->loadXML($document)`
- **OWASP Category:** A05:2021 – Security Misconfiguration (XXE, CWE-611)
- **Problem:** `DOMDocument::loadXML()` is called without any `LIBXML_*` flags (no `LIBXML_NONET`, no explicit entity-loading disablement). If running on an older PHP/libxml combination, or if `libxml_disable_entity_loader(false)` is set elsewhere in the app for other features, this is a classic XXE vector — an attacker uploading a crafted CDA document could read local files or trigger SSRF.
- **Severity:** High

### Finding 4 — SSRF via configurable external validator URL
- **Location:** `CdaValidateDocuments.php::__construct()` and `ettValidateDocumentRequest()`
- **OWASP Category:** A10:2021 – Server-Side Request Forgery
- **Problem:** `$GLOBALS['mdht_conformance_server']` is an admin-configurable URL that the server will `curl_init`/POST a file to, with `CURLOPT_SSL_VERIFYPEER` controllable via `$GLOBALS['http_verify_ssl']`. If this setting can be influenced by a lower-privileged admin role or is not restricted to trusted internal use, it's an SSRF primitive (can be pointed at internal/metadata endpoints). Even in an intended "admin-only" design, disabling SSL verification (`http_verify_ssl = false`) weakens transport security for data containing PHI (the CCDA document itself) being sent over the network.
- **Severity:** Medium (requires admin access to configure, so impact is reduced, but PHI exfiltration risk via SSRF/MITM is real).

### Finding 5 — Sensitive PHI written to predictable temp file
- **Location:** `CdaValidateDocuments.php::ettValidateDocumentRequest()` — `$post_file = $GLOBALS['temporary_files_dir'] . '/ccda.xml'; file_put_contents($post_file, $xml);`
- **OWASP Category:** A01:2021 – Broken Access Control / A02:2021 – Cryptographic Failures (sensitive data exposure)
- **Problem:** The CCDA document (containing PHI) is written to a fixed, predictable filename (`ccda.xml`) in a shared temp directory with no apparent cleanup (no `unlink()` after use), no randomization, and no explicit file permission hardening. Concurrent requests could overwrite each other's data, and if the temp directory is web-accessible or shared across users on a multi-tenant host, this is a PHI disclosure risk. The file is never deleted after the cURL request completes.
- **Severity:** Medium–High (PHI exposure, HIPAA-relevant).

### Finding 6 — Command execution / local service startup risks
- **Location:** `CdaValidateDocuments.php::startValidationService()`
- **OWASP Category:** A05:2021 – Security Misconfiguration / A08 (Software and Data Integrity) — command execution via `exec()`/`popen()`
- **Problem:** Builds a shell command via `escapeshellcmd()` and executes with `exec($cmd . " > /dev/null &")` / `popen("start /B " . $cmd, "r")`. `escapeshellcmd` only escapes shell metacharacters but is not a substitute for `escapeshellarg` when constructing paths from `$GLOBALS['fileroot']` — if `fileroot` or `temporary_files_dir` can ever be influenced by configuration in an insecure deployment, there's a command injection risk. Low likelihood since these come from server config, not user input, but worth noting as defense-in-depth is weak here.
- **Severity:** Low (requires config-level compromise already).

### Finding 7 — Logging of validation errors may leak PHI into logs
- **Location:** `CdaValidateDocuments.php::validateXmlXsd()` — `$this->getSystemLogger()->errorLogCaller("CDA XSD Validation Errors", ['errors' => $xsd_log['xsd']]);`
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures (improper data handling in logs)
- **Problem:** XSD validation error messages can include fragments of the document content/line context, which may contain PHI, being written to general system logs. Ensure the logging sink is access-controlled and retention/redaction policies account for PHI in CDA documents.
- **Severity:** Low–Medium

## Conclusion
The diff itself is a legitimate security hardening fix (removal of `LIBXML_XINCLUDE`), with no new vulnerabilities introduced. However, it only partially addresses XXE/XInclude risk in `XmlExtended.php`, and the surrounding/consuming code in `CdaValidateDocuments.php` has several pre-existing issues (unguarded `DOMDocument::loadXML`, SSRF via admin-configurable validator URL, PHI written to predictable temp files without cleanup, and potential PHI leakage into logs) that should be remediated as part of a broader hardening pass.