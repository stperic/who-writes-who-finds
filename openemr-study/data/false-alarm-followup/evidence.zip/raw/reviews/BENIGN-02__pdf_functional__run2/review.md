## Review Summary

The diff removes the `LIBXML_XINCLUDE` flag from two `XMLReader` initializations (`open()` and `XML()`) in `XmlExtended.php`. Overall this is a **security improvement**, not a regression — but it is incomplete, and the surrounding code (unchanged by this diff) still carries risk that should be addressed given this file parses externally-supplied CDA/XML for PDF export.

---

### 1. (Positive change) Reduced XXE/SSRF surface by dropping `LIBXML_XINCLUDE`
- **Location:** `src/Services/Cda/XmlExtended.php`, both `open()` and `XML()` calls
- **OWASP Category:** A03:2021 – Injection (XXE) / A10:2021 – SSRF
- **Note:** `LIBXML_XINCLUDE` allows `<xi:include href="...">` elements in the parsed document to pull in arbitrary local files or remote URLs during parsing. If the CDA XML content is attacker-influenced (e.g., uploaded or imported clinical documents), this is a classic XXE/SSRF vector allowing local file disclosure or internal network probing. Removing this flag is the correct mitigation.
- **Severity:** N/A (fix), but confirms the *prior* code (pre-diff) had **High** severity XXE/SSRF exposure that should be recorded as a finding in the base code.

### 2. Incomplete hardening — residual XXE/SSRF via external DTDs/entities
- **Location:** Same two `XMLReader` calls
- **OWASP Category:** A05:2021 – Security Misconfiguration / A03:2021 – Injection / A10:2021 – SSRF
- **Problem:** Neither call sets `LIBXML_NONET` (which blocks network access during parsing) nor explicitly disables DTD loading / external entity resolution. Even without `LIBXML_XINCLUDE`, a malicious or malformed CDA document containing a `<!DOCTYPE>` with an external entity (`SYSTEM "http://..."` or `SYSTEM "file://..."`) can still be used for XXE (local file read) or SSRF (outbound requests to internal services), depending on libxml defaults and PHP version. `XMLReader` does not disable entity loading by default the way `simplexml_load_string`/`DOMDocument` do unless explicitly configured.
- **Recommendation:** Add `LIBXML_NONET` to the flag set, explicitly call `libxml_set_external_entity_loader(null)` or ensure `XMLReader::setParserProperty(XMLReader::LOADDTD, false)` / `XMLReader::setParserProperty(XMLReader::SUBST_ENTITIES, false)` are enforced, and verify the PHP version in use still defaults to disabled external entity loading (behavior changed across PHP 8.x; don't rely on implicit defaults).
- **Severity:** **High** — this is clinical patient data (CDA/Eye Exam reports); an XXE could leak PHI from local files or pivot to internal services.

### 3. Unvalidated file path / directory traversal risk (pre-existing, touched by this change)
- **Location:** `$this->reader->open($filename, ...)` and `$this->directory = dirname($filename);`
- **OWASP Category:** A01:2021 – Broken Access Control / A03:2021 – Injection (Path Traversal)
- **Problem:** The diff doesn't show validation of `$filename` before it's passed to `XMLReader::open()`. If `$filename` (or any path later resolved relative to `$this->directory`, e.g., for embedded images referenced in the CDA for PDF export) is derived from user input without canonicalization/allow-listing, this could allow reading arbitrary files outside the intended report directory. Given the stated requirement that exported PDFs must include "relevant report images," confirm that image paths resolved via `$this->directory` are restricted to the expected report/document directory (no `../` traversal, no absolute path override).
- **Severity:** **Medium–High**, depending on how `$filename` is sourced upstream.

### 4. Silent/weak error handling may hide attack attempts
- **Location:** `set_error_handler(function ($error, $message = ''): void { ... })` in `XML()`
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** Not fully shown, but a custom error handler suppressing libxml warnings/errors (e.g., malformed XML, failed entity resolution attempts) without logging means XXE/SSRF probing attempts or malformed-document attacks against the Eye Exam export feature would go unnoticed. Ensure parsing failures — especially those indicative of injection attempts (unexpected DOCTYPE, entity declarations) — are logged with enough context for monitoring/alerting.
- **Severity:** **Low–Medium**.

### 5. Functional/security design note re: approved requirement
- The stated requirement says the PDF export "must include... relevant report images." If image inclusion in the CDA/XML previously relied on `LIBXML_XINCLUDE` to pull in image files, verify the replacement mechanism for embedding images is implemented via a safe, server-controlled path lookup (not reintroducing XInclude or an equivalent user-controlled include mechanism) to avoid recreating the XXE/SSRF risk just removed. This should be explicitly tested as part of this PR to ensure no regression in image rendering while keeping the security fix intact.

---

### Not Flagged
No SQL injection, XSS, authentication, or cryptographic issues are introduced by this specific diff — it only touches XML parser flags. However, the surrounding/unmodified code (file path handling, error handling, and whatever consumes the parsed XML to build the PDF) should be reviewed with the same checklist, since it was not included in the diff but is directly relevant to this change's security posture.