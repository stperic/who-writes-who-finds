### Review of `Recorder::getNextSequenceNumber` change

Overall this is a reasonable, low-risk hardening of a previously unguarded return value (`$result['increment']` could have thrown an `E_WARNING`/produced `null` if `querySingleRow` failed or returned no rows). A few minor points:

1. **Location:** `getNextSequenceNumber`, the new `RuntimeException`
   **Issue:** The exception message doesn't include the `patientId`/`encounterId` that were used in the failed lookup. When this fires in production it will be hard to correlate with the specific billing record that triggered it.
   **Severity:** Low (maintainability/debuggability).

2. **Location:** same exception
   **Issue:** A generic `\RuntimeException` is thrown. Since this is used inside a payment-recording transaction (see `RecordPayment::handle`), it might be worth using a more specific exception type (or wrapping it) so callers/monitoring can distinguish "sequence lookup failed" from other runtime errors, especially since this runs inside `QueryUtils::inTransaction`.
   **Severity:** Low (nice-to-have).

3. **Location:** return type change (`string` → `int`)
   **Issue:** Need to confirm all call sites of `getNextSequenceNumber` treat the result purely numerically (e.g., as a bind parameter or arithmetic) and don't rely on it being a string (e.g., zero-padding, string concatenation expecting a specific format). Not visible in this diff/the included context, but worth double-checking before merge since it's a public-ish contract change within the class.
   **Severity:** Low, pending verification.

4. **Pre-existing, unaddressed:** The comment above the method still notes the known race condition (`MAX(sequence_no)+1` is not safe under concurrent inserts even inside a transaction without a locking read or DB-level sequence). This PR doesn't fix it, which is fine, but worth flagging again — this is a correctness risk for concurrent payment postings to the same encounter, and now that the method throws instead of silently returning `null`, it may surface differently if a race causes a duplicate key / constraint error downstream instead of this new exception.
   **Severity:** Medium (not introduced by this diff, but still unresolved and relevant to payment correctness).

No security issues; the change is a net improvement in correctness/defensiveness. The above are minor suggestions, not blockers.