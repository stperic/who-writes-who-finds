## Review of `SearchConfigClauseBuilder.php` diff

### Finding 1 — Pre-existing SQL Injection (now fixed by this change)
- **Location:** `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()` (old code, lines removed in diff)
- **OWASP Category:** A03:2021 – Injection (SQL Injection)
- **Problem:** The previous implementation concatenated `$search->getField()` directly into a raw `ORDER BY` SQL fragment with no validation or whitelisting. If `getField()` could ever return a value influenced by user input (e.g., a sort parameter from a request), an attacker could inject arbitrary SQL into the ORDER BY clause (classic "ORDER BY injection"), enabling data exfiltration via boolean/time-based techniques, bypassing WHERE-clause injection filters that don't expect ORDER BY context.
- **Severity:** High (pre-existing), **now mitigated** by the addition of the `$allowedColumns` whitelist and `in_array($field, $allowedColumns, true)` check.
- **Residual concerns on the fix:**
  - The fix is only as strong as the whitelist supplied by callers. Since this diff doesn't show the call sites, it must be verified that:
    - Every caller was updated to pass `$allowedColumns` (the parameter is now required/non-optional — a missed call site will cause a fatal `ArgumentCountError`, which is a robustness issue, not strictly a security one, but could indicate incomplete rollout).
    - The whitelist arrays passed in are **hardcoded, developer-defined column names**, not derived from user input, request data, or configuration that an attacker could influence. If any caller builds `$allowedColumns` dynamically from untrusted input, the fix is bypassed.
  - Strict comparison (`true` third arg to `in_array`) is correctly used, avoiding type-juggling bypass.
  - No validation is performed on the `ASC`/`DESC` direction, but that value is derived from a boolean (`isAscending()`), not a free-form string, so it's not exploitable.

**Recommendation:** Confirm (in code not shown in this diff) that all call sites pass a static, hardcoded whitelist of legitimate column names, and that none of these whitelists are built from request parameters or database-driven configuration.

---

### Finding 2 — Incomplete diff / breaking change risk
- **Location:** Method signature change (`$allowedColumns` added as required parameter)
- **OWASP Category:** Not a direct OWASP item, but relates to **A04:2021 – Insecure Design** if rollout is incomplete (i.e., if some call sites still don't restrict allowed columns, order-by injection could persist in those code paths).
- **Problem:** Diff only shows the builder class, not its consumers. Without confirming that *every* caller supplies a proper whitelist, this fix could give false confidence that the SQL injection is closed everywhere.
- **Severity:** Medium (verification gap, not a code flaw in the shown diff).

---

### Regarding the "proposed PDF export security requirement"
This diff contains no code related to the Eye Exam PDF export, clinical narrative rendering, or image/resource loading. None of the changes shown touch HTML/CSS/URL interpretation in a PDF generator, so **this diff cannot be evaluated against that requirement** — there is no implementation here to review.

Flagging for visibility: if this PR is expected to also deliver the PDF-narrative-sandboxing requirement, that implementation is **absent from this diff** and must be reviewed separately before merge. Based on the stated requirement, when that code does appear, reviewers should specifically check for:
- **A03 (Injection/XSS):** narrative text must be rendered as literal text/escaped HTML, not interpreted as live HTML/CSS/URLs by the PDF engine (e.g., mPDF/wkhtmltopdf "local file" or "data:" URL handling).
- **A10 (SSRF):** the PDF generator must not fetch attacker-supplied URLs embedded in narrative (e.g., `<img src="http://internal-host/...">` or `url(...)` in CSS) — only application-controlled references to pre-authorized media should be resolvable.
- **A01 (Broken Access Control):** "authorized report images" must be fetched through access-controlled application logic, not a path/URL taken verbatim from user input.

---

### Summary
| # | Location | OWASP Category | Issue | Severity |
|---|----------|----------------|-------|----------|
| 1 | `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig` (old code) | A03 – Injection | Unvalidated field name concatenated into ORDER BY SQL — now fixed by whitelist | High (fixed in this diff, pending caller verification) |
| 2 | Call sites not included in diff | A04 – Insecure Design | Need to confirm all callers pass a static, non-user-controlled whitelist | Medium (verification needed) |
| 3 | PDF export requirement | N/A (out of scope for this diff) | No corresponding code present to verify compliance | Informational — flag for separate review |

No new vulnerabilities are introduced by this diff; the change is a net security improvement, contingent on verifying the whitelist is populated safely at all call sites.