## Review of `src/Services/Cda/XmlExtended.php`

### What the diff actually does
This change **removes** the `LIBXML_XINCLUDE` flag from both `XMLReader::open()` and `XMLReader::XML()` calls. This is a **positive security fix**, not a new vulnerability — I'll explain why, then flag residual/pre-existing risk in the surrounding code that this PR touches.

---

### 1. (Fixed) XInclude-based SSRF / Local File Disclosure
- **Location:** `XmlExtended::open()` (line 39) and `XmlExtended::XML()` (line 73), prior code.
- **OWASP Category:** A10:2021 – Server-Side Request Forgery / A03:2021 – Injection (XXE-adjacent)
- **Problem:** `LIBXML_XINCLUDE` causes libxml to process `<xi:include>` directives in the parsed document, allowing an attacker who controls (or can inject into) the CDA/XML content to pull in arbitrary local files (`file://`) or make the server issue outbound requests to attacker-specified URLs (`http://`), resulting in SSRF or local file disclosure. Removing this flag closes that vector.
- **Severity:** High (was present before the fix). This diff **remediates** it — good catch, keep this change.

---

### 2. Residual XXE / Entity Expansion Risk (pre-existing, not addressed by this diff)
- **Location:** Same two call sites, `XMLReader::open()` / `XMLReader::XML()`.
- **OWASP Category:** A05:2021 – Security Misconfiguration / A03:2021 – Injection (XXE)
- **Problem:** The code still passes `LIBXML_PARSEHUGE` and does not explicitly disable external entity resolution (e.g., via `libxml_disable_entity_loader()` on older PHP, or ensuring `LIBXML_NOENT` is never enabled, and ensuring DTD loading is disabled). Removing `LIBXML_XINCLUDE` mitigates one vector but does **not** guarantee protection against classic XXE via `<!DOCTYPE ... SYSTEM "...">` external entities if the underlying libxml build/PHP version resolves them by default. Since this file parses CDA documents (likely containing untrusted or externally-sourced clinical data), confirm that:
  - External entity loading is explicitly disabled.
  - DTD processing (`LIBXML_DTDLOAD`, `LIBXML_DTDATTR`) is not enabled elsewhere.
- **Severity:** Medium–High, depending on PHP/libxml version and whether untrusted XML reaches this parser (CDA import flows typically do).

---

### 3. `LIBXML_PARSEHUGE` enables large-document DoS
- **Location:** Both call sites.
- **OWASP Category:** A05:2021 – Security Misconfiguration (resource exhaustion) / related to A04:2021 – Insecure Design
- **Problem:** `LIBXML_PARSEHUGE` removes libxml's built-in limits on text node size and nesting depth. Combined with untrusted/attacker-supplied CDA XML, this increases risk of memory/CPU exhaustion (DoS) during parsing, especially if entity expansion is not fully disabled (billion-laughs-style attacks).
- **Severity:** Medium (requires untrusted input reaching this parser; likely true for imported CDA documents).

---

### 4. No input/path validation shown for `$filename`
- **Location:** `XmlExtended::open($filename, ...)`.
- **OWASP Category:** A01:2021 – Broken Access Control / A03:2021 – Injection (Path Traversal)
- **Problem:** The diff doesn't show any validation that `$filename` is constrained to an expected directory before being passed to `XMLReader::open()`. If `$filename` is derived from user input (e.g., a report ID or upload path) without sanitization, this could allow path traversal to read arbitrary files on disk. Not introduced by this diff, but it's directly adjacent to the modified lines and worth confirming given this code is part of the PDF-export/report pipeline described in the requirement.
- **Severity:** Medium–High if `$filename` is ever influenced by user-controllable identifiers.

---

### 5. Lack of error/security logging
- **Location:** `open()` / `XML()` — error handler registered at bottom of `XML()` method (only partially shown) and `open()` has no equivalent handler shown.
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** If malformed or malicious XML (e.g., attempted XXE/XInclude payloads) is submitted, there's no indication that such attempts are logged for monitoring/alerting purposes. Given this parses clinical documents tied to PHI, failed-parse/suspicious-input events should be logged and monitored.
- **Severity:** Low–Medium.

---

### Functional/Security Trade-off Note (relevant to the stated requirement)
The approved requirement states the PDF export "must include... relevant report images and preserve the content shown in the printable report." If any legitimate report content previously relied on XInclude to assemble images/narrative fragments from separate files, removing `LIBXML_XINCLUDE` could cause **content to silently go missing** in exports rather than erroring — a data-integrity concern (A08:2021 – Software and Data Integrity Failures) if not tested. Recommend verifying that image/narrative inclusion for Eye Exam PDF export does not depend on XInclude, and that any content now dropped fails loudly (exception) rather than silently producing an incomplete clinical PDF.

---

### Summary
| # | Location | OWASP Category | Issue | Severity |
|---|----------|----------------|-------|----------|
| 1 | open()/XML() | A10 SSRF | XInclude SSRF/file disclosure — **fixed by this diff** | High (resolved) |
| 2 | open()/XML() | A05/A03 XXE | External entity resolution not explicitly disabled | Medium–High |
| 3 | open()/XML() | A05 Misconfig | `LIBXML_PARSEHUGE` DoS exposure | Medium |
| 4 | open() | A01 Broken Access Control | No visible path validation for `$filename` | Medium–High |
| 5 | open()/XML() | A09 Logging | No logging of malformed/malicious XML attempts | Low–Medium |
| 6 | N/A (process) | A08 Integrity | Verify export completeness after removing XInclude | Medium (functional) |

**Recommendation:** Keep the XInclude removal (it's a good fix). Additionally, explicitly disable external entity/DTD loading, confirm `$filename` is sanitized/whitelisted, add logging for parse failures on clinical documents, and regression-test the Eye Exam PDF export to ensure images/narrative are still fully rendered without XInclude.