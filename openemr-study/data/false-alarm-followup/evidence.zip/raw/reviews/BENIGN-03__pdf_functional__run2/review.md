## Security Review

### 1. New Access-Control Check – Possible Logic/Design Gap
**Location:** `interface/billing/get_claim_file.php`, new `if` block
**OWASP Category:** A01:2021 – Broken Access Control
**Problem:**
The check only verifies that the user has *write* permission on `acct/eob` **or** `acct/bill`. Retrieving/downloading a file is a read operation, so requiring "write" ACL is an odd design choice that could either:
- Over-restrict legitimate read-only billing staff (availability/business issue), or
- Be a copy-paste from a different endpoint without verifying this is actually the intended ACL section/level for *viewing* a claim file.

There is no visibility into how the actual claim file parameter (e.g., a file name/ID in `$_GET`) is validated afterward. If the file identifier is taken from user input and used to build a path without validating that the authenticated user is authorized to access *that specific* claim (ownership/tenant check), this is an **IDOR** vulnerability — the new ACL check only confirms the user has a generic billing role, not that they're entitled to this specific claim file. This should be confirmed in the code not shown in the diff.
**Severity:** Medium–High (depends on downstream file-selection logic, which should be audited for IDOR/path traversal).

---

### 2. Order of Checks – CSRF Validated After Access Check (Minor)
**Location:** Same file
**OWASP Category:** A01:2021 – Broken Access Control / Design
**Problem:**
Not a vulnerability per se, but worth noting: the ACL check now runs before CSRF verification. This is generally fine (deny early), but ensure `denyWithTemplate()` does not leak any CSRF-protected state or produce side effects before CSRF is verified. If `denyWithTemplate` renders a page with sensitive data/state changes without CSRF protection, that would be an issue — not evident here, likely fine.
**Severity:** Informational.

---

### 3. Information Disclosure via Error Message
**Location:**
```php
AccessDeniedHelper::denyWithTemplate("ACL check failed for acct/eob or acct/bill: Billing Manager", xl("Billing Manager"));
```
**OWASP Category:** A05:2021 – Security Misconfiguration (verbose error handling) / A09 overlap
**Problem:**
The denial message explicitly reveals internal ACL section/object names (`acct/eob`, `acct/bill`) to the client. While low severity, this helps an attacker map out the internal authorization model for further privilege-escalation attempts. Depending on `denyWithTemplate`'s implementation, this string may be shown directly in the UI/logs, or just used for internal logging — need to confirm it isn't rendered to the end user. If rendered to user, should be genericized.
**Severity:** Low.

---

### 4. Missing Security Logging for Access-Denied Events
**Location:** New ACL check block
**OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
**Problem:**
No explicit audit-log entry is created when an unauthorized user attempts to access a billing/claim file. Given this endpoint serves potentially sensitive PHI/claim data, failed authorization attempts should be logged (who, when, what resource) to support incident detection and investigation. (Depends on whether `AccessDeniedHelper::denyWithTemplate` internally logs — should be verified; if not, this is a gap.)
**Severity:** Low–Medium.

---

### 5. Pre-existing Risk: File Retrieval Logic Not Shown (Must Be Audited)
**Location:** Rest of `get_claim_file.php` (not included in diff)
**OWASP Category:** A01:2021 – Broken Access Control / A03:2021 – Injection (Path Traversal)
**Problem:**
This endpoint, by name, retrieves a claim file from disk/storage based on a request parameter. The diff does not show how that parameter is sanitized. Classic risks in this kind of code (common in OpenEMR historically) include:
- Path traversal (`../../etc/passwd`-style payloads) if the filename isn't canonicalized/whitelisted.
- IDOR if the claim ID/file is not checked against the authenticated user's patient/facility scope.
These must be reviewed even though not changed in this diff, since the PR explicitly touches the access-control gate for this exact concern.
**Severity:** High (if unaddressed in existing code).

---

### 6. Pre-existing Risk: CSRF Token Passed via GET
**Location:** `if (!CsrfUtils::verifyCsrfToken($_GET["csrf_token_form"]))`
**OWASP Category:** A02:2021 – Cryptographic Failures / A01 (sensitive token exposure)
**Problem:**
CSRF tokens transmitted via GET query string are more likely to leak through browser history, proxy/server logs, and `Referer` headers when the page links out to external resources. This is pre-existing but directly relevant to this endpoint's security posture.
**Severity:** Low–Medium.

---

## Summary
The added ACL check is a good step toward fixing what was very likely a **missing access control** vulnerability (any authenticated user could previously call `get_claim_file.php` with only CSRF protection, no role check). However:

- The specific ACL requirement (write access to billing/eob) should be double-checked against intended least-privilege semantics for a *read* operation.
- The file-selection/path logic downstream (not shown) must be audited for **IDOR** and **path traversal**, as the ACL check alone does not guarantee the user is authorized to access the *specific* claim file requested.
- Minor hardening opportunities: avoid leaking ACL object names in denial messages, add audit logging on denial, and consider moving CSRF tokens off the query string.

Given the sensitivity of billing/claim data (PHI), I'd flag this PR as **incomplete/needs-followup** until the file access logic itself is confirmed to properly scope access per claim/patient, not just per general billing role.