# Security Review – `interface/billing/get_claim_file.php`

## Finding 1: Possible fail-open if `denyWithTemplate()` does not terminate execution
- **Location:** `get_claim_file.php`, new lines calling `AccessDeniedHelper::denyWithTemplate(...)`
- **OWASP Category:** A01:2021 – Broken Access Control
- **Problem:** The new ACL check is a good addition, but its security value depends entirely on `AccessDeniedHelper::denyWithTemplate()` calling `exit`/`die` after rendering the "access denied" page. If that helper merely prints a template and *returns* (rather than halting the script), execution will fall through to the CSRF check and then to the rest of the file-retrieval logic, completely defeating the access control check. This pattern (print-then-continue) is a common source of broken access control bugs in PHP codebases.
- **Severity:** High (contingent on `denyWithTemplate()` implementation — must be verified; if it doesn't terminate, this is Critical).

## Finding 2: Use of `write` permission to gate what is presumably a read/download action
- **Location:** `AclMain::aclCheckCore('acct', 'eob', '', 'write')` / `AclMain::aclCheckCore('acct', 'bill', '', 'write')`
- **OWASP Category:** A01:2021 – Broken Access Control (incorrect authorization model)
- **Problem:** `get_claim_file.php` appears to serve/download a claim/EOB file — a read operation. Gating it on `write` ACL rather than `view`/`read` either (a) unnecessarily blocks legitimate read-only billing staff, or (b) more importantly, if there exists a separate, more permissive `read` capability that should have been used, this mapping should be double-checked against OpenEMR's ACL model to ensure it matches the principle of least privilege and existing conventions elsewhere in the billing module. Worth confirming this isn't simply reusing a convenient check without matching actual intended access semantics.
- **Severity:** Low–Medium (depends on ACL design intent).

## Finding 3: No security logging of access-denied events
- **Location:** New ACL check block
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** When the ACL check fails, there is no audit/event log entry recording the unauthorized access attempt (who attempted it, from where, for which claim). OpenEMR has an audit logging facility (`EventAuditLogger` / `newEvent`) used elsewhere for sensitive actions; failing to log denied access to billing/claim files reduces ability to detect probing or privilege-escalation attempts.
- **Severity:** Low–Medium.

## Finding 4: Pre-existing/out-of-diff risk — file path handling in the rest of `get_claim_file.php`
- **Location:** Not shown in diff, but relied upon by this change (the code that actually resolves/reads the claim file after the new checks).
- **OWASP Category:** A01:2021 – Broken Access Control / Path Traversal (also A03 Injection if path built via concatenation)
- **Problem:** The diff only adds an ACL gate before the existing CSRF check and file-serving logic. The patch does not show how the requested file name/path is derived (e.g., from `$_GET`/`$_REQUEST`) or whether it is validated against a whitelist/claim-ownership check before being read and streamed to the client. If the underlying logic builds a filesystem path from user input without canonicalization and strict ownership validation, this remains vulnerable to path traversal / arbitrary file disclosure regardless of the new ACL check, since the ACL check is role-based (any user with `bill`/`eob` write access could still traverse to arbitrary files if the path isn't bound to the requesting user's permitted claims). This should be reviewed even though it isn't part of this diff.
- **Severity:** High (if unvalidated — needs verification against the full file).

## Finding 5: Ordering — ACL check before authentication is assumed already established by `globals.php`
- **Location:** Top of file, `require_once(__DIR__ . "/../globals.php");`
- **OWASP Category:** A07:2021 – Identification and Authentication Failures (context check only)
- **Problem:** Not a flaw introduced by this diff, but worth confirming `globals.php` for this script enforces that a session is authenticated before the ACL check runs; `aclCheckCore` typically relies on `$_SESSION['authId']` being set. If an unauthenticated request could reach this point (e.g., session fixation/missing `authCheckSession()` call for this particular endpoint), the ACL check could behave unpredictably (e.g., default-deny vs. default-permit on undefined session user). Recommend confirming this endpoint is included in the authenticated-only routing/interface set.
- **Severity:** Informational/Low (dependent on existing framework guarantees).

---

## Regarding the "Eye Exam PDF export" security requirement
The supplied PDF-export requirement (about preventing HTML/CSS/URL/file-path injection being interpreted as resource references by a PDF generator, and restricting image/resource loading to application-controlled references) **does not correspond to any code in this diff**. The diff only touches `interface/billing/get_claim_file.php` and does not involve PDF generation, Eye Exam narratives, or image/resource loading. There is nothing in this changeset to evaluate against that requirement — if a PDF-export diff was intended to be included, it appears to be missing. No SSRF/XSS/file-inclusion assessment can be made for that feature based on the code actually provided.

---

### Summary
The core change (adding an ACL check) is a legitimate and positive **fix for Broken Access Control**, but its effectiveness hinges on confirming that `AccessDeniedHelper::denyWithTemplate()` halts script execution (Finding 1 is the most critical item to verify before merge). Additionally, the diff's context reveals pre-existing, unverified risk in file path handling in the same file that should be audited as part of this change's review scope.