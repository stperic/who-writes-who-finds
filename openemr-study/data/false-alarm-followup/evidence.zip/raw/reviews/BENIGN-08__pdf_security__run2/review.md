## Review of `src/PaymentProcessing/Recorder.php` diff

### 1. Race condition in sequence number generation (pre-existing, not addressed)
- **Location:** `getNextSequenceNumber()`, the `SELECT MAX(sequence_no)+1` query.
- **OWASP category:** A04:2021 – Insecure Design (also has data-integrity implications, A08:2021).
- **Problem:** The code's own comment acknowledges a TOCTOU race: two concurrent calls can read the same `MAX(sequence_no)`, both compute the same "next" value, and both insert rows with a duplicate `sequence_no` for the same `pid`/`encounter`. This change only tightens the return type/validation but does not fix the underlying concurrency flaw. For payment/activity ledger records, duplicate or colliding sequence numbers can cause financial record corruption, inconsistent audit trails, or logic that assumes uniqueness of `sequence_no` to silently misbehave.
- **Severity:** Medium–High, given this is financial/payment data where integrity matters. Should be fixed with `SELECT ... FOR UPDATE`, an atomic `INSERT ... SELECT`, or a unique constraint + retry, as the original comment suggests.

### 2. Failure path has no security logging
- **Location:** New `throw new \RuntimeException(...)` branch.
- **OWASP category:** A09:2021 – Security Logging and Monitoring Failures.
- **Problem:** When the sequence lookup returns unexpected/non-numeric data (which could indicate DB corruption, unexpected schema change, or an attempt to manipulate query results), the code throws but does not log the anomaly with context (patientId, encounterId, raw result). In a payment-processing path, silently failing without an audit trail makes it harder to detect tampering or investigate incidents.
- **Severity:** Low.

### 3. Minor: type coercion edge cases
- **Location:** `is_numeric($increment)` / `(int) $increment`.
- **OWASP category:** Not a distinct OWASP Top-10 item, but worth noting as a correctness/integrity nit.
- **Problem:** `is_numeric` accepts strings like `"1e3"` or `"  10"` (depending on PHP version) which, when cast to `int`, could yield surprising truncation (e.g., `1e3` → `1`). Unlikely to be attacker-controlled here since the value comes from `MAX()+1` on a presumably integer column, but if `sequence_no` is ever a non-integer column type or influenced by application input elsewhere, this could produce incorrect sequence numbers rather than failing safely.
- **Severity:** Low.

### No SQL injection
The query uses parameterized placeholders (`?`) via `QueryUtils::querySingleRow`, so this specific snippet is not vulnerable to SQL injection, assuming `QueryUtils` properly binds parameters (not shown, but consistent with existing usage pattern).

### Regarding the proposed PDF export security requirement
This diff does not touch any PDF generation / Eye Exam report code, so the stated requirement (narrative must be treated strictly as content, not as HTML/CSS/URL/file-path resource references; images only via application-controlled references) is **not implemented or verifiable from this change**. If this PR is intended to also address that requirement, it currently does not — flag separately and ensure the PDF generation pipeline (wherever it lives) sanitizes/escapes narrative text and restricts resource loading (no `file://`, external URLs, or `<img src="javascript:...">`-style SSRF/path traversal vectors) before merge.

---
**Summary:** No new injection, auth, or crypto vulnerabilities introduced by this diff. The main carried-over concern is the unresolved sequence-number race condition (Insecure Design / data integrity), plus a minor logging gap on the new error path. The PDF-export requirement in the prompt is unrelated to and unaddressed by this diff.