## Summary

This diff removes the `LIBXML_XINCLUDE` flag from two `XMLReader` calls in `XmlExtended.php`. On its own, this is a **security improvement**, not a regression — but it's incomplete, and the surrounding code (which this diff still relies on) has related weaknesses worth flagging given this class parses CDA XML, which is often exchanged with external systems/providers.

---

### 1. (Positive change, but incomplete) XInclude processing removed — residual XXE/SSRF risk remains
- **Location:** `src/Services/Cda/XmlExtended.php`, `open()` and `XML()` methods (both `XMLReader::open()`/`XMLReader::XML()` calls)
- **OWASP category:** A03:2021 – Injection (XXE) / A10:2021 – SSRF / A05:2021 – Security Misconfiguration
- **Problem:** `LIBXML_XINCLUDE` previously allowed `<xi:include href="...">` directives in parsed XML to pull in arbitrary local files or remote URLs — a classic vector for local file disclosure and SSRF when parsing XML from an untrusted or semi-trusted source (e.g., CDA documents received from external facilities/HIEs). Removing the flag is the right move, **but**:
  - The flags retained (`LIBXML_COMPACT | LIBXML_PARSEHUGE`) do **not** include `LIBXML_NONET`, so if DTD processing or external entity resolution is still reachable through other code paths, the parser could still attempt network/file access.
  - There is no visible call to disable DTD loading (e.g., `XMLReader::setParserProperty(XMLReader::LOADDTD, false)` / `XMLReader::setParserProperty(XMLReader::VALIDATE, false)`) or to `libxml_disable_entity_loader()`/equivalent hardening for the libxml version in use. Classic XXE (external entity file disclosure, SSRF, or billion-laughs DoS via internal entity expansion) may still be possible depending on PHP/libxml defaults.
- **Severity:** Medium (was likely High before this fix for the XInclude vector specifically; residual XXE/DoS risk via DTDs/entities remains if input is untrusted).
- **Recommendation:** Explicitly add `LIBXML_NONET`, disable DTD loading/validation, and confirm entity substitution is off. Add a regression test that feeds a malicious XML payload (XInclude, external entity, and DOCTYPE-based) to confirm it's rejected/neutralized.

### 2. Trust boundary of `$filename` / XML source not established
- **Location:** `open($filename, ...)` 
- **OWASP category:** A10:2021 – Server-Side Request Forgery / A01:2021 – Broken Access Control
- **Problem:** `XMLReader::open()` accepts stream wrappers (`http://`, `ftp://`, `phar://`, etc.), not just local paths. This diff doesn't show where `$filename` originates. If any caller constructs this path from user-controlled input (uploaded report ID, file path parameter, etc.) without strict validation against an allow-listed local directory, this could be leveraged for SSRF or arbitrary file read.
- **Severity:** High if `$filename` is influenced by request data; Informational/Low if always server-generated from a trusted path.
- **Recommendation:** Verify/enforce that `$filename` is always a fully resolved, validated path within an expected directory (reject absolute URLs and `..` traversal) before reaching this class.

### 3. Error handling may suppress security-relevant signals
- **Location:** `set_error_handler(function ($error, $message = '') ...)` in `XML()`
- **OWASP category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** The custom error handler (body not shown in diff) appears to intercept libxml/XML parsing errors. If it only suppresses warnings without logging malformed/malicious payloads (e.g., attempts to use XInclude, external entities, oversized documents), attempted exploitation attempts against this parser won't be detected or auditable.
- **Severity:** Low-Medium.
- **Recommendation:** Ensure parsing failures (especially ones indicative of injection attempts) are logged with enough context (source, user/session) for monitoring, without leaking sensitive data into logs.

### 4. Functional/security interaction with the stated PDF export requirement
- **Location:** N/A (design-level, relevant to this change)
- **OWASP category:** A04:2021 – Insecure Design
- **Problem:** The approved requirement states exported PDFs must preserve "relevant report images." If images were previously pulled in via XInclude, removing it may break that functionality, creating pressure to reintroduce `LIBXML_XINCLUDE` or build an ad hoc replacement (e.g., string-concatenating file paths into the XML) later under deadline — which could reintroduce the same XXE/path-traversal/SSRF risk this diff just fixed.
- **Severity:** Medium (process risk, not an active vulnerability in this diff).
- **Recommendation:** If images need to be embedded, use a controlled, allow-listed mechanism (e.g., resolve image references server-side from a validated, access-controlled image store and embed as base64/binary attachments) rather than relying on libxml's XInclude or any other dynamic external-resource inclusion.

---

## Not found
- No SQL injection, XSS, hard-coded secrets, authentication/authorization changes, or dependency version bumps are present in this diff.
- No broken access control changes are introduced here (export authorization is presumably enforced elsewhere; not shown in this diff — should be independently verified, but out of scope for these two lines).

## Overall assessment
This is a net positive security fix (reducing XXE/SSRF exposure via XInclude), but it should be treated as a **partial hardening**, not a complete XXE remediation. Recommend explicitly adding `LIBXML_NONET`, disabling DTD loading, validating the trust level/source of parsed XML and `$filename`, and ensuring any replacement mechanism for including report images does not reopen the same class of vulnerability.