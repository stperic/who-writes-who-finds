## Review of `interface/billing/get_claim_file.php` diff

### 1. Positive change (for context)
The diff adds an authorization check that did not exist before. Prior to this patch, any authenticated user who could reach this endpoint (and obtain/guess a valid CSRF token) could retrieve claim files regardless of billing permissions — a broken access control condition (OWASP A01:2021). Adding the `AclMain::aclCheckCore()` check is the right direction. However, several issues remain or are introduced:

---

### 2. Unverified control-flow termination on access denial
**Location:** `get_claim_file.php`, new `if (!AclMain::aclCheckCore(...)) { AccessDeniedHelper::denyWithTemplate(...); }` block.

**OWASP Category:** A01:2021 – Broken Access Control (CWE-696: Incorrect Behavior Order).

**Problem:** The code does not explicitly `exit`/`die`/`return` after calling `AccessDeniedHelper::denyWithTemplate()`. `AccessDeniedHelper` is not included in the provided files, so it cannot be confirmed that this helper terminates script execution internally. If it merely renders a "access denied" page/template but does not halt execution, PHP will continue executing the rest of the script (CSRF check, and more importantly the file-disclosure logic below), completely defeating the purpose of the new check. This is a common anti-pattern and must be verified/tested explicitly (e.g., unit test confirming no file bytes are returned on a denied request).

**Severity:** High (if the helper doesn't terminate execution, this is a full access-control bypass; otherwise, non-issue). Must be verified before merge.

---

### 3. CSRF token transmitted via GET
**Location:** Pre-existing line, now sitting after the new ACL check: `CsrfUtils::verifyCsrfToken($_GET["csrf_token_form"])`.

**OWASP Category:** A02:2021 – Cryptographic Failures / Sensitive Data Exposure (also relates to A05 Security Misconfiguration).

**Problem:** The CSRF token is read from the query string rather than a POST body or header. GET parameters are commonly leaked via browser history, server/proxy access logs, and the `Referer` header when the page subsequently loads third-party resources. Since this endpoint serves what appears to be billing/claim data (PHI/PII-adjacent), leaking the CSRF token could allow a secondary actor (e.g., someone with log access, or a malicious third-party resource on the same page) to forge a request if they can also predict/observe the required URL. This is pre-existing design but the PR relies on/extends it, so it should be flagged.

**Severity:** Medium.

---

### 4. Ordering of authorization vs. CSRF validation
**Location:** New ACL block placed before the CSRF check.

**OWASP Category:** A01:2021 – Broken Access Control / Insecure Design.

**Problem:** Not itself a vulnerability, but worth noting: performing the ACL check before CSRF validation means an attacker with a stolen/predicted session but invalid CSRF token will get a clearer "access denied due to role" response rather than a generic CSRF failure — this is a minor information disclosure about role assignment but low impact. More importantly, confirm CSRF validation still executes for authorized users (i.e., the new block doesn't accidentally short-circuit or get bypassed through an early return elsewhere).

**Severity:** Low.

---

### 5. Scope of the ACL check vs. object-level authorization (IDOR risk) — cannot be verified from diff
**Location:** `get_claim_file.php` (file body below the shown diff, not included).

**OWASP Category:** A01:2021 – Broken Access Control (potential IDOR, CWE-639).

**Problem:** The new check only validates that the user has the global `acct/eob` or `acct/bill` **write** permission. It does not appear to validate that the specific claim/file being requested belongs to a patient/encounter/facility the user is permitted to access (multi-facility or multi-tenant restrictions are common in OpenEMR). If the actual file-serving code further down derives a file path or claim ID directly from user-supplied input (`$_GET`) without verifying ownership/facility scoping, this would still allow a billing user from one facility to pull claim files belonging to another facility/patient — i.e., global role-based check without object-level check. This can't be confirmed or ruled out from the diff alone and should be verified against the rest of `get_claim_file.php`.

**Severity:** High (if object-level check is missing) — requires verification against the full file.

---

### 6. Reliance on `AclMain::aclCheckCore` superuser bypass and empty-user behavior
**Location:** `src/Common/Acl/AclMain.php::aclCheckCore()` (pre-existing, relied upon by this change).

**OWASP Category:** A07:2021 – Identification and Authentication Failures (minor) / A01 Broken Access Control.

**Problem:** `aclCheckCore` silently defaults `$user` to the session's `authUser`, and if no session user exists, checks ACLs for an empty username (`''`). While this likely resolves to "deny" (no ACL rows for user `''`), it's a fragile pattern — if any ACL/group were ever mapped to an empty username (misconfiguration), this would grant/deny incorrectly. This is pre-existing and not introduced by the diff, but the new code directly relies on this trust boundary with no additional check that a user is actually authenticated before calling `aclCheckCore`. Confirm `globals.php` (included above the diff) enforces authentication before this point; if not, an unauthenticated request could reach the ACL check and get unexpected behavior depending on Gacl configuration.

**Severity:** Low/Medium — relies on upstream authentication guarantees not shown in this diff.

---

### 7. No input validation/escaping visible for `csrf_token_form` or any file/claim identifier parameters
**Location:** Entire diff context — the actual request parameters used to select the claim file are not shown.

**OWASP Category:** A03:2021 – Injection / Path Traversal (CWE-22), if applicable.

**Problem:** Cannot confirm from the diff whether the file path is built from `$_GET` parameters safely (e.g., via indirect database lookup) or concatenated directly (path traversal risk). Flagging for reviewer to check the unmodified portion of `get_claim_file.php`.

**Severity:** Unknown — requires review of full file; potentially Critical if direct path concatenation from user input exists.

---

## Summary
- The intent of this PR (adding missing billing ACL checks) is a good and necessary fix for a pre-existing broken access control gap.
- **Before merging**, confirm that `AccessDeniedHelper::denyWithTemplate()` terminates script execution (critical — otherwise the fix is a no-op).
- Verify object-level (claim/patient/facility) authorization exists beyond the role-level check, to avoid IDOR.
- Note the pre-existing weaknesses (CSRF token in GET, reliance on `aclCheckCore`'s empty-user handling) as technical debt, even though not introduced by this diff.
- No SQL injection, XSS, SSRF, or deserialization issues are introduced by this specific diff.