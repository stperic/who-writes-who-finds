## Review Comments

**Location:** `src/PaymentProcessing/Recorder.php`, `getNextSequenceNumber()`

### 1. Verify call site compatibility with return-type change (Low/Medium)
The return type was changed from `string` to `int`. Since this is a `private` method, check whatever currently consumes `getNextSequenceNumber()`'s return value (not shown in the diff) — e.g. if the result is interpolated directly into SQL as a string or concatenated with other string values, an `int` should coerce fine, but if it relies on string formatting (e.g. zero-padding) the behavior will silently change. Worth a quick grep to confirm the consumer is fine with an `int`.

### 2. Generic exception type (Minor/Nit)
Throwing a bare `\RuntimeException` for "could not determine next sequence number" works but doesn't give callers a way to distinguish this specific failure mode from other runtime errors. Given this is used inside a payment-recording transaction (see `RecordPayment::handle`), a more specific exception (e.g. a custom `SequenceNumberException`) would make it easier for callers/tests to assert on and handle appropriately — though this is a style preference, not a blocker.

### 3. Logging before throwing (Minor)
Since this is in a payment-critical path wrapped in `QueryUtils::inTransaction`, it might be worth logging the failure (with patient/encounter IDs) before throwing, to aid debugging when this unexpected condition occurs in production, since the exception message itself doesn't include the `$patientId`/`$encounterId` context.

### 4. Pre-existing race condition not addressed (Informational, not a new issue)
The comment above the method still correctly notes the race condition on concurrent inserts (`MAX(sequence_no)+1` without a locking read). This PR doesn't fix it, which is fine since it's out of scope, but it's worth flagging again since this method is being touched — a follow-up ticket reference would help future readers know this is tracked rather than forgotten.

### Overall
The core change (validating the DB result and failing fast with a clear exception instead of silently returning `null`/non-numeric data) is a solid correctness/reliability improvement over the previous implicit trust in the query result. No blocking issues found — the above are minor suggestions.