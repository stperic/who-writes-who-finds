## Review of `get_claim_file.php` ACL addition

### What the diff does well
It adds an authorization check that was apparently missing before (previously the file only checked a CSRF token, with no evidence of any ACL/permission check at all). Adding `AclMain::aclCheckCore()` gating is a genuine improvement. However, several concerns remain, both in the new code and in what it relies on.

---

### Issue 1 — Broken Access Control: module-level check only, no object/resource-level authorization
**Location:** `interface/billing/get_claim_file.php`, new `if` block
**OWASP Category:** A01:2021 – Broken Access Control (IDOR)
**Problem:** The new check only verifies that the logged-in user has *module-level* `write` permission on `acct/eob` or `acct/bill`. It does **not** verify that the specific claim/file being requested (presumably identified by an ID or filename in `$_GET`) belongs to a patient/encounter/facility the user is actually permitted to access. If the file-selection parameter is attacker-controllable (e.g., a claim id, patient id, or file path passed via `$_GET`), any user who has generic billing-write rights (which in many OpenEMR deployments is a fairly broad group of billing staff) could retrieve claim files for patients outside their facility, provider panel, or care team — a classic Insecure Direct Object Reference.
**Severity:** High (pending confirmation from the rest of the file, which was not included in this diff — strongly recommend reviewing the file/claim lookup logic for ownership checks).

---

### Issue 2 — Potential over/under-restriction of permission level (least-privilege design concern)
**Location:** Same `if` block
**OWASP Category:** A01:2021 – Broken Access Control / Insecure Design
**Problem:** The function requires the `write` return value specifically for both `acct/eob` and `acct/bill`. Retrieving/downloading a claim file is logically a *read* operation. Tying a read action to `write` ACL is unusual — if OpenEMR installations have users with only `view`-level bill/eob access (a legitimate "read-only billing" role), they will be wrongly denied, while conversely any site that only differentiates `write` could end up granting this broad read action to a large set of users whose intended scope was limited to a narrower billing task. Verify this matches the actual intended access model for claim-file retrieval rather than copy-pasting an existing `write` check pattern from elsewhere.
**Severity:** Low–Medium (business-logic/design risk rather than a direct exploit).

---

### Issue 3 — Missing security logging for sensitive data access
**Location:** New `if` block / overall endpoint
**OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
**Problem:** Claim files typically contain PHI/financial data. The code calls `AccessDeniedHelper::denyWithTemplate()` on failure, but there is no visible logging of either successful access or failed authorization attempts to the OpenEMR audit log (`EventAuditLogger`/`system_logger`), which OpenEMR uses elsewhere for PHI access. Without visibility into `AccessDeniedHelper`'s implementation, it's unclear whether denial events are logged; successful access clearly is not logged in this diff.
**Severity:** Medium — important for HIPAA-style audit trails on PHI access/download endpoints.

---

### Issue 4 — Unreviewed file-serving logic (inherited risk, not shown in diff)
**Location:** Rest of `get_claim_file.php` (not included in the diff)
**OWASP Category:** A01:2021 (Path Traversal / Broken Access Control), possibly A03 (Injection) if the filename is used in a filesystem/SQL call
**Problem:** The function name and purpose ("get a claim file") strongly suggest the script reads a file from disk or storage using a parameter from the request. This diff does not show (and therefore cannot verify) that the file path/identifier is validated against a safe allow-list or resolved through a trusted database lookup rather than directly from user input. OpenEMR has had historical path-traversal/LFI issues in similarly named "get_*" download endpoints. This should be explicitly reviewed since the new ACL check does not mitigate a path traversal vulnerability if one exists in the unseen code.
**Severity:** Unknown/Potentially Critical — flagged for mandatory review before merge; cannot be conclusively assessed from this diff alone.

---

### Issue 5 — Reliance on `AclMain::aclCheckCore()` default/superuser bypass semantics
**Location:** `src/Common/Acl/AclMain.php::aclCheckCore()` (pre-existing, relied upon by this change)
**OWASP Category:** A01:2021 – Broken Access Control (context awareness)
**Problem:** `aclCheckCore()` automatically grants access to any user with `admin/super`, and silently defaults `$user` to whatever is in the session (`authUser`) if not provided. This is pre-existing and consistent with the rest of the codebase, but it means the new check in `get_claim_file.php` provides *no* defense if the session/authentication mechanism itself is compromised (e.g., session fixation or an unauthenticated code path reaching this file). Confirm this script is only reachable through the authenticated interface session handling in `globals.php`, since this ACL check is the only gate being added here.
**Severity:** Informational/Low (not introduced by this diff, but the new control inherits this trust boundary).

---

### Not applicable / no findings
- No SQL injection, XSS, SSRF, or cryptographic issues are introduced by this diff; the change is limited to adding an ACL gate.
- CSRF protection was already present and is preserved; ordering (ACL check before CSRF check) is not a security problem since both are enforced before any processing occurs.

---

### Summary
The added ACL check is a positive step but is likely insufficient on its own: it only enforces coarse-grained, role/module-level authorization and may still allow object-level (IDOR) access to arbitrary claim files if the underlying file-selection logic doesn't separately verify resource ownership. Please show/review the remainder of `get_claim_file.php` (the actual file lookup/serving code) before approving, and confirm audit logging exists for this PHI-adjacent endpoint.