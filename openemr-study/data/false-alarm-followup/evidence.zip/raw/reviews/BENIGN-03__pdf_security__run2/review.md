## Review of `interface/billing/get_claim_file.php` diff

### 1. Positive change (for context)
Adding the `AclMain::aclCheckCore()` gate before the file is served is a genuine improvement — previously this endpoint had **no authorization check at all**, only CSRF validation. That said, several issues remain or are introduced:

---

### 2. Possible Insufficient / Coarse-Grained Authorization (IDOR risk)
**Location:** new `if (!AclMain::aclCheckCore(...))` block
**OWASP Category:** A01:2021 – Broken Access Control
**Problem:** The check only verifies that the user holds the *role-level* permission `acct/eob` or `acct/bill` with `write`. It does not appear to verify that the specific claim/file being requested belongs to a patient/encounter the user is authorized to access (object-level authorization). If the endpoint takes a claim ID / filename from `$_GET` later in the file, any user with generic billing-write access could potentially retrieve claim files for patients outside their facility/care team (classic IDOR). This can't be fully confirmed without seeing the rest of the file, but it should be verified — the ACL check alone does not substitute for record-level authorization.
**Severity:** Medium–High (pending confirmation of downstream file-lookup logic)

---

### 3. CSRF token passed via GET
**Location:** `CsrfUtils::verifyCsrfToken($_GET["csrf_token_form"])` (pre-existing, but directly adjacent/relied upon by this change)
**OWASP Category:** A07:2021 – Identification and Authentication Failures / A05 Security Misconfiguration
**Problem:** CSRF tokens transmitted in the query string are more likely to leak via browser history, proxy/server access logs, and the `Referer` header when the page links to external resources. Tokens used for sensitive actions should be transmitted via POST body or headers, not GET parameters.
**Severity:** Low–Medium (pre-existing, but the endpoint now explicitly gates sensitive billing data behind this weak CSRF transport)

---

### 4. No security logging for access-denied or access-granted events
**Location:** New ACL check and the file-serving logic following it (not shown)
**OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
**Problem:** There is no `EventAuditLogger`/audit trail entry recorded when access is denied or when a claim file is actually retrieved. For sensitive billing/PHI-adjacent documents, failed authorization attempts and successful downloads should be logged for incident response and compliance (HIPAA audit trail expectations).
**Severity:** Medium

---

### 5. Error-message disclosure via `AccessDeniedHelper`
**Location:** `AccessDeniedHelper::denyWithTemplate(...)`
**OWASP Category:** A01:2021 – Broken Access Control / A05 Security Misconfiguration
**Problem:** The denial message explicitly states which ACL sections are required ("ACL check failed for acct/eob or acct/bill: Billing Manager"). This is consistent with existing OpenEMR conventions, but it does give an unauthenticated/unauthorized caller information about the internal permission model. Low impact given this is standard elsewhere in the app, but worth flagging as unnecessary information disclosure.
**Severity:** Low

---

### 6. Unverified downstream file access logic (pre-existing, relied upon by this change)
**Location:** Rest of `get_claim_file.php` (not included in diff)
**OWASP Category:** A01:2021 – Broken Access Control / A03:2021 – Injection (Path Traversal)
**Problem:** Since this file's purpose is to fetch and stream a claim file based on request parameters, and the diff does not show the file path/ID handling code, it should be independently confirmed that:
- The file path is not constructed by directly concatenating user-supplied input (risk of path traversal / arbitrary file read).
- The claim identifier is validated to belong to the authenticated user's authorized scope (patient/facility), not just checked against a blanket "bill/eob write" permission.
This is a pre-existing condition that this PR's ACL check does **not** fully remediate if such a flaw exists.
**Severity:** Unknown — High if present

---

### Note on the "Eye Exam PDF" requirement
The provided proposed-pdf-export-security-requirement (about preventing HTML/CSS/URL/file-path injection into PDF rendering and restricting resource loading to application-controlled references) is **not applicable to this diff** — this change concerns `get_claim_file.php`, an access-control fix for claim file retrieval, not PDF generation for Eye Exam reports. No PDF-rendering code is touched here, so there is nothing in this diff to evaluate against that requirement. If an Eye Exam PDF export diff is submitted separately, it should be reviewed against SSRF (A10:2021) and injection (A03:2021) risks from narrative-to-HTML rendering, as that requirement implies.

---

## Summary
| # | Issue | Category | Severity |
|---|-------|----------|----------|
| 2 | Possible object-level authorization gap (IDOR) | A01 Broken Access Control | Medium–High |
| 3 | CSRF token in GET query string | A07 / A05 | Low–Medium |
| 4 | No audit logging for access grant/deny | A09 Logging & Monitoring | Medium |
| 5 | Verbose denial message (info disclosure) | A01 / A05 | Low |
| 6 | Unverified file path/ID handling downstream | A01 / A03 | Unknown–High |

The added ACL check is a good step forward, but the PR should be accompanied by verification of items #2 and #6 (the actual file-serving logic) before being considered a complete fix for access control on this endpoint.