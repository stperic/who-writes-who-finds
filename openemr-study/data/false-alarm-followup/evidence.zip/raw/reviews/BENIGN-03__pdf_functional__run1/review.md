## Review of `interface/billing/get_claim_file.php` diff

**Overall**: This change is a good step — it adds a missing authorization check in front of a billing/EOB file download endpoint, which is a legitimate OWASP A01 (Broken Access Control) fix. However, there are several points that need to be verified/addressed before merge.

---

### 1. ACL check may use the wrong permission level
- **Location**: `AclMain::aclCheckCore('acct', 'eob', '', 'write')` / `AclMain::aclCheckCore('acct', 'bill', '', 'write')`
- **Category**: A01 – Broken Access Control (incorrect authorization level / least privilege)
- **Problem**: This endpoint *retrieves/downloads* a claim/EOB file — a read operation — but the check requires `write` permission on `acct/eob` or `acct/bill`. If OpenEMR's ACL model distinguishes view vs. write, this could either (a) deny staff who should legitimately be able to view/export billing files but only have read access, or (b) more importantly, isn't the real concern — the bigger risk is making sure `write` is actually the correct/intended gate and not a copy-paste from another write-type endpoint. This should be confirmed against the ACL matrix; mismatched permission levels are a common source of access-control bugs.
- **Severity**: Medium (pending confirmation of intended ACL semantics)

### 2. No object-level (IDOR) authorization shown
- **Location**: Whole file (not shown in diff, but relied upon)
- **Category**: A01 – Broken Access Control (Insecure Direct Object Reference)
- **Problem**: The new check only verifies that the user has the `acct/eob` or `acct/bill` *role capability*, not that the specific claim/patient/encounter referenced by the request parameters is one the user is actually permitted to access (e.g., patient-level access controls, facility restrictions). If the rest of the script builds the file path/query directly from `$_GET` parameters, a user with generic billing-write access could potentially pull another patient's claim file by changing an ID. This needs to be confirmed in the surrounding code that wasn't included in the diff.
- **Severity**: High (if no further per-record check exists downstream)

### 3. Does `AccessDeniedHelper::denyWithTemplate()` actually terminate execution?
- **Location**: New `if` block calling `AccessDeniedHelper::denyWithTemplate(...)`
- **Category**: A01 – Broken Access Control (fail-open condition)
- **Problem**: If this helper merely renders a "no access" page/template but does not call `exit`/`die` afterward, execution will continue to the CSRF check and the rest of the script, effectively bypassing the access-control gate entirely (fail-open). This must be verified in `AccessDeniedHelper`'s implementation — not shown in this diff.
- **Severity**: Critical if it does not halt execution; otherwise N/A.

### 4. No logging of denied access attempts
- **Location**: New ACL check
- **Category**: A09 – Security Logging and Monitoring Failures
- **Problem**: There is no explicit audit log entry (e.g., via OpenEMR's `EventAuditLogger`) recording who attempted to access a billing file without sufficient privilege. If `denyWithTemplate()` doesn't log this internally, unauthorized access attempts to sensitive billing/PHI-adjacent data go unrecorded, hindering incident detection on a HIPAA-regulated system.
- **Severity**: Medium

---

### Pre-existing issues touched by this change (not introduced here, but relevant)

### 5. CSRF token passed via GET
- **Location**: `CsrfUtils::verifyCsrfToken($_GET["csrf_token_form"])`
- **Category**: A02/A05 – Cryptographic/Design weakness in CSRF handling
- **Problem**: Transmitting the CSRF token in the query string means it can leak via browser history, proxy/server access logs, and the `Referer` header to third-party resources. Tokens used for state-changing or sensitive-data-returning actions should ideally be sent via POST body or custom headers.
- **Severity**: Low–Medium (pre-existing)

### 6. Unverified file-path/query construction
- **Location**: Rest of `get_claim_file.php` (not included in diff)
- **Category**: A03 – Injection (Path Traversal / SQL Injection depending on implementation)
- **Problem**: Since the endpoint's job is to fetch a claim file by ID, if that ID is used to build a filesystem path or SQL query without parameterization/sanitization, this could allow path traversal or SQLi. This isn’t visible in the diff, but because the PR touches this file's security gate, it should be re-verified as part of this review that the underlying read logic is parameterized and that file paths are resolved against a safe base directory with no `../` traversal.
- **Severity**: Unknown/High if unmitigated — needs confirmation.

---

### Summary Table

| # | Location | OWASP Category | Issue | Severity |
|---|----------|-----------------|-------|----------|
| 1 | ACL check | A01 Broken Access Control | `write` permission used for a read/export action — confirm intent | Medium |
| 2 | Whole file | A01 Broken Access Control | No evident per-record/IDOR check beyond role ACL | High |
| 3 | `denyWithTemplate()` call | A01 Broken Access Control | Must confirm execution halts on denial | Critical if not |
| 4 | ACL check | A09 Logging & Monitoring | No audit log of denied attempts | Medium |
| 5 | CSRF check | A02 Cryptographic/Design | CSRF token sent via GET | Low–Medium (pre-existing) |
| 6 | File retrieval logic | A03 Injection | Unverified sanitization of file/claim identifiers | Unknown/High (pre-existing, needs verification) |

**Recommendation**: Before merging, confirm (a) `AccessDeniedHelper::denyWithTemplate()` terminates the request, (b) the correct ACL level (`view` vs `write`) is being checked, and (c) the underlying file-retrieval code enforces per-patient/per-record authorization and safe file-path handling.