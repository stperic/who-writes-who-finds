## Review Comments

**Location:** `interface/billing/get_claim_file.php`, new ACL check block

**Issue 1 — ACL check placed before CSRF verification (ordering/defense-in-depth concern)**
Severity: Low/Informational

The ACL check is added before the CSRF check. This is generally fine and arguably preferable (deny unauthorized users before doing any other work), but worth confirming this is intentional and consistent with other files in the codebase. Not a blocker, just a note for consistency.

**Issue 2 — Missing explicit `return`/`exit` after `denyWithTemplate()`**
Severity: Medium

```php
if (!AclMain::aclCheckCore(...) && !AclMain::aclCheckCore(...)) {
    AccessDeniedHelper::denyWithTemplate(...);
}
```
It's not shown in this diff whether `denyWithTemplate()` itself terminates execution (e.g., via `exit`/`die`). If it does not halt script execution, the code below (CSRF check, and presumably file-serving logic) will still execute even after an access-denied response is rendered, potentially leaking the claim file content or causing duplicate/broken output. This should be verified, and ideally an explicit `exit;` should follow the call for defense-in-depth, regardless of whether the helper exits internally.

**Issue 3 — No read-only/view access path**
Severity: Low (depends on intended behavior)

The check only allows access if the user has **write** access to `acct/eob` or `acct/bill`. If this endpoint is used to simply *view/download* a claim file (as the name `get_claim_file.php` suggests), restricting to `write` permission only may be overly restrictive and block users who should have read-only access to claims/billing but not edit rights. Worth confirming this matches the intended access model — if viewing a claim file should only require `view` (or no specific return_value), this check may need adjustment. Conversely, if `write` is intentional because the endpoint also permits mutating actions, this is fine — but it should be documented/confirmed.

**Issue 4 — No logging of denied access attempt**
Severity: Low

Unlike many ACL enforcement points elsewhere in OpenEMR, there's no explicit audit/event logging call here before denying access (depends on what `denyWithTemplate` does internally). If `denyWithTemplate` doesn't already log this, an unauthorized access attempt against billing/claim data won't be recorded, which could be a compliance/auditability gap for PHI-adjacent data.

**Issue 5 — Correctness of the overall change**
Severity: Positive / None

Functionally, adding an ACL gate to a previously-unprotected billing endpoint is a good and necessary security fix (this looks like it's closing an access-control gap — any authenticated user could previously fetch claim files). No issues with the ACL check logic itself; `aclCheckCore` usage matches conventions elsewhere in the codebase.

---

### Summary
The change is a reasonable and needed security fix, but the reviewer should confirm:
1. `AccessDeniedHelper::denyWithTemplate()` actually terminates execution (add explicit `exit` if not, or if there's any doubt).
2. Whether `write` permission is the correct requirement or whether `view`/empty return_value is more appropriate for a "get file" (read) operation.