## Review

**Location:** `src/Services/Cda/XmlExtended.php`, lines removing `LIBXML_XINCLUDE`

**Issue:** The `LIBXML_XINCLUDE` flag has been removed from both `XMLReader::open()` and `XMLReader::XML()` calls without any accompanying explanation (commit message/comment) or compensating logic.

- **Correctness/Behavioral concern (Medium-High):** `LIBXML_XINCLUDE` enables automatic processing of XInclude directives (`<xi:include>`) in the XML being parsed. If any CDA documents processed by this reader rely on XInclude to pull in external content (which is plausible given this class also tracks a `directory` property, suggesting external file references), this change will silently stop resolving those includes. This could cause silent data loss/truncation in parsed CDA documents rather than an obvious error, which is especially risky for clinical document parsing where missing content could affect data integrity.

- **Security consideration (Medium):** If the motivation for this change was to mitigate an XXE/XInclude-based SSRF or file-disclosure vulnerability (XInclude can be abused similarly to external entities to read arbitrary local files or make the parser fetch external resources), that's a reasonable security fix. However:
  - The diff doesn't show any other hardening (e.g., `libxml_disable_entity_loader`, restricting `LIBXML_NOENT`, or sanitizing the `directory` usage elsewhere in the class).
  - There's no comment explaining why the flag was removed, making it hard for future maintainers to know whether this was deliberate hardening or an oversight.

- **Maintainability (Medium):** No code comment or changelog note explains the rationale. A reviewer/future developer cannot tell if this is a security fix, a bug fix, or an accidental regression. This ambiguity is a red flag in a security-sensitive parsing class handling clinical documents.

- **Missing test coverage (Low-Medium):** There's no indication (in the diff) that existing tests cover XInclude-containing CDA samples. If such documents are part of the expected input, this change could break parsing silently in production without any test catching it.

### Recommendation
1. Add a comment explaining why `LIBXML_XINCLUDE` was removed (e.g., "Removed to prevent XXE/SSRF via XInclude" or "No longer needed since X").
2. Verify whether any supported CDA documents actually use XInclude; if so, either keep the flag with proper sanitization/restrictions, or explicitly document that XInclude support is now unsupported and update any related documentation/error handling for malformed documents that used to rely on it.
3. Add a regression test confirming expected behavior with and without XInclude directives in sample documents.
4. If this is indeed a security fix, consider pairing it with other XXE hardening measures (e.g., ensuring `libxml_disable_entity_loader()`/equivalent safe defaults are enforced) for defense in depth.