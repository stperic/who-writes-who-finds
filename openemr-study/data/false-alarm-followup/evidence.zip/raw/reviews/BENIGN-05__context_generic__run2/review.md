## Review Comments

### 1. `library/auth.inc.php` – lines 106‑116 (restructured timeout block)
**Problem (Correctness / Regression):**
The semantics of `skip_timeout_reset` have changed in a way that is not mentioned in the PR and likely breaks its original purpose.

- **Before:** if `skip_timeout_reset` was set, the *entire* block — including the `isSessionExpired()` check — was skipped. Background/polling requests (Messages, Reminders, Flow Board) never triggered `authCloseSession()`/`authLoginScreen()`.
- **After:** `skip_timeout_reset` now only suppresses the *update* of the expiration timer (`updateSessionExpiration()`). The `isSessionExpired()` check — and the resulting forced logout (`authCloseSession()` + `authLoginScreen(true)`) — now runs unconditionally for every request, including those that explicitly asked to skip timeout handling.

Consequences:
- Background AJAX endpoints that previously never triggered a logout will now call `authLoginScreen(true)`, which presumably returns an HTML login page. Callers expecting JSON (e.g., Messages/Reminders polling, Flow Board) will likely break or throw JS errors when the session has timed out, instead of failing gracefully or being ignored as before.
- Each poll request after expiration will now log a `"timeout, so force logout"` audit event and call `authCloseSession()` repeatedly (e.g., from multiple open tabs/background pollers), which can spam the audit log and possibly cause repeated attempts to tear down an already-closed session.

This is a meaningful behavioral change hidden inside what looks like a simple refactor, and it directly contradicts the comment's own stated intent ("mechanism to skip the timeout and timeout reset mechanisms" / "e.g., background polling ... that opts out").

**Severity:** High — functional regression affecting background polling reliability and potentially user session handling; needs explicit confirmation this was intended, with corresponding test coverage.

---

### 2. `library/auth.inc.php` – same block
**Problem (Performance):**
Previously, requests with `skip_timeout_reset` set skipped the SQL lookup done inside `isSessionExpired()` entirely. Now that lookup runs on every request regardless of `skip_timeout_reset`, adding a DB round-trip to every background polling call (which can be frequent, e.g., every few seconds per open tab for Messages/Reminders/Flow Board).

**Severity:** Low–Medium — minor added DB load, but could matter at scale with many concurrent sessions/tabs.

---

### Summary
The diff is a readability improvement on the surface, but it silently changes the semantics of `skip_timeout_reset`, which previously bypassed the entire timeout check for background/polling requests. This should either be reverted to preserve the original behavior (skip whole block when `skip_timeout_reset` is present) or called out explicitly as an intentional behavior change, with testing to ensure background endpoints handle the forced-logout response correctly.