## Review Summary

This diff is a **security‑positive** change: it retrofits a whitelist check onto `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()`, which previously built an `ORDER BY` clause by directly concatenating a caller/user‑supplied field name into raw SQL. That is a textbook SQL Injection sink. The fix is good, but there are some residual concerns worth flagging, both in the diff and in the code it touches.

---

### 1. (Pre‑existing, now fixed by this PR) SQL Injection via unsanitized ORDER BY field
- **Location:** `src/Services/Search/SearchConfigClauseBuilder.php`, old version of `buildSortOrderClauseFromConfig()` (line removed: `$clauses[] = $search->getField() . " " . (...)`)
- **OWASP Category:** A03:2021 – Injection
- **Problem:** The old code took `$search->getField()` — ultimately derived from a user-controllable sort parameter (e.g., FHIR `_sort`) — and concatenated it directly into the SQL `ORDER BY` clause with no validation or escaping. Since column identifiers cannot be parameterized with bound placeholders, any caller that passed through a request-controlled field name would have been vulnerable to classic SQL injection (including blind/time-based injection for data exfiltration).
- **Severity:** Critical (pre‑patch). **Status:** Fixed by this PR via the new `$allowedColumns` strict whitelist check (`in_array($field, $allowedColumns, true)`), and the fail-closed behavior (unmatched fields are dropped, and an entirely empty clause list correctly yields `""` instead of a malformed `ORDER BY`).

This is a solid mitigation using an allow-list approach, which is the correct way to handle dynamic identifiers that can't be parameterized.

---

### 2. Security of the fix is entirely dependent on every caller supplying a safe, hard‑coded whitelist
- **Location:** `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()` (new signature) and its only visible caller, `PatientService::search()` / `PatientService::ALLOWED_SORT_COLUMNS`.
- **OWASP Category:** A04:2021 – Insecure Design
- **Problem:** The function is only as safe as the `$allowedColumns` array passed in. The diff doesn't enforce (and can't easily enforce) that this list is a hard-coded, developer-controlled constant rather than something built dynamically from request data or configuration. `PatientService` does this correctly (`ALLOWED_SORT_COLUMNS` is a private `const`), but this PR does not show whether **other existing callers** of this previously 2-argument method were updated. Since the method signature changed from optional/implicit to a **required** second parameter, any caller not updated in this PR will either:
  - fail to compile/throw a `TypeError` at runtime (availability issue), or
  - be patched elsewhere with a loosely-constructed allow-list (potentially reintroducing injection) that isn't visible in this diff.
- **Recommendation:** Audit the full codebase for all call sites of `buildSortOrderClauseFromConfig()` to confirm (a) they’ve been updated to pass a column list, and (b) that list is a static, hard-coded whitelist — never derived from request input, config stored in the DB, or reflection over entity properties.
- **Severity:** Medium (depends entirely on code not shown in this diff).

---

### 3. No logging of rejected/suspicious sort fields
- **Location:** `buildSortOrderClauseFromConfig()`, the `continue;` branch when a field fails the whitelist check.
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** When an invalid/disallowed sort field is supplied (which is a strong signal of either a bug or an active injection attempt against the `_sort` parameter), it is silently dropped with no logging, metrics, or alerting. This is good for availability (fail-closed) but means injection probing attempts against this API surface would go completely unnoticed.
- **Severity:** Low. Recommend adding a debug/security log entry (e.g., via `SystemLogger`) when a disallowed sort field is rejected, including user/session context, to support detection of exploitation attempts.

---

### 4. Unqualified column names in a multi-table JOIN query (pre-existing, touched by this change)
- **Location:** `PatientService::search()` — the `$orderBy` string is injected into SQL that joins `patient_data`, `patient_history`, `users`, `contact`, `contact_address`, and `addresses`. Several of these tables share column names with `patient_data` columns allowed in `ALLOWED_SORT_COLUMNS` (e.g. `id`, `date`, `uuid`).
- **OWASP Category:** A04:2021 – Insecure Design (robustness) / tangential A05 Security Misconfiguration if it causes a query error path.
- **Problem:** The whitelist only checks that the name is an allowed string; it doesn't qualify it with a table prefix (e.g., `patient_data.id`). In a query with multiple joined tables containing identically named columns, an unqualified `ORDER BY id` or `ORDER BY date` is ambiguous and could either cause a SQL error (handled by `QueryUtils::sqlStatementThrowException`, likely raising an exception — a possible unhandled-exception/DoS vector) or silently sort by an unintended table's column depending on MySQL's resolution rules. This isn't attacker-controlled injection anymore (thanks to the whitelist), but it's a correctness/robustness gap introduced by relying on bare identifiers in a complex join.
- **Severity:** Low/Informational. Recommend fully qualifying allowed columns (e.g., `patient_data.id`) in the whitelist or when building the clause.

---

### Other OWASP categories checked — no issues found in this diff
- **Broken Access Control:** N/A — this method has no authorization logic itself; access control for patient search is handled upstream (not shown/changed here).
- **Cryptographic Failures:** N/A — no crypto/secrets involved.
- **XSS:** N/A — server-side SQL clause builder, no output rendering.
- **Vulnerable/Outdated Components:** No dependency changes in this diff.
- **Identification/Authentication:** N/A — not touched.
- **Software/Data Integrity:** N/A — no deserialization, no CI/CD or update mechanism changes.
- **SSRF:** N/A — no outbound network requests involved.

---

## Conclusion
The diff itself remediates a genuine, previously-existing SQL Injection vulnerability (A03:2021) by introducing a strict allow-list for `ORDER BY` field names, and does so correctly and safely for the one call site shown (`PatientService`). The residual risk is **not** in the code shown, but in ensuring (1) every other caller of this now-modified method also passes a safe, hard-coded whitelist, and (2) adding detection/logging for rejected fields to catch injection attempts. A minor hardening suggestion is to fully qualify whitelisted column names given the multi-table joins in `PatientService::search()`.