## Review of `src/PaymentProcessing/Recorder.php` diff

**Scope note:** This diff only changes the return type handling of `getNextSequenceNumber()` — it adds a type check/cast and throws if the DB didn't return a numeric value. The SQL query itself is unchanged and already uses parameterized placeholders (`?`), so there is no SQL injection introduced or present here.

### No new vulnerabilities introduced
The added validation (`is_numeric` check + exception) is a defensive improvement — it prevents a non-numeric or malformed result from silently propagating into billing/accounting logic, which is a good practice.

---

### Pre-existing issue touched by this change (not fixed)

**Location:** `getNextSequenceNumber()`, `src/PaymentProcessing/Recorder.php:204+`
**OWASP Category:** A04:2021 – Insecure Design (also relates to A08 – Software and Data Integrity Failures, since it affects the integrity of generated sequence numbers)
**Problem:** The existing code comment explicitly acknowledges a TOCTOU race condition: `SELECT MAX(sequence_no)+1` followed by a separate `INSERT` is not atomic, even inside a transaction (unless using `SELECT ... FOR UPDATE` or a serializable isolation level). Under concurrent requests for the same `pid`/`encounter`, two callers could compute the same "next" sequence number and both insert it, producing duplicate `sequence_no` values in `ar_activity`. In a payment-processing/accounting context, duplicate or skipped sequence numbers can cause reconciliation errors, double-counting, or data integrity problems in financial records.
**Severity:** Medium (financial/accounting data integrity risk; exploitability depends on concurrency in production, not an external attacker-facing vector, but still a real correctness/integrity defect in payment code).
**Recommendation:** Since this function was touched, this would have been a good opportunity to actually fix the race (e.g., `SELECT ... FOR UPDATE` inside the transaction, or compute the sequence number as part of the `INSERT` using a subquery/locking strategy, or use a dedicated sequence/counter table with atomic increment).

---

### Regarding the proposed PDF export security requirement
This diff does not touch any PDF generation, Eye Exam report, or HTML/CSS rendering code. The stated requirement (preventing HTML/CSS/URL/file-path injection from being treated as a resource reference in the PDF generator, and restricting image/resource loading to application-controlled references) is **not addressed by this diff** and cannot be verified from the code shown. If there is PDF-generation code elsewhere in the codebase that handles user-controlled narrative text, it should be reviewed separately for:
- **A03:2021 – Injection (XSS/HTML injection into PDF renderer)** if narrative text is interpolated into HTML/CSS before PDF rendering without escaping.
- **A10:2021 – Server-Side Request Forgery** if the PDF generator resolves URLs/file paths found in user content (e.g., `<img src="...">`, CSS `url()`, or font/file references) and fetches them, allowing an attacker to make the server request internal/external resources.

No such code is present in this diff, so this is flagged only as an area to confirm is covered elsewhere, not as a finding against the code shown.

---

### Summary
- No vulnerabilities introduced by this diff.
- Diff improves robustness (fails safely instead of returning `null`/non-numeric values).
- Pre-existing race condition in sequence-number generation remains unaddressed (Medium severity, Insecure Design).
- The PDF export security requirement is unrelated to this diff and should be verified against the actual PDF-generation code, which is not included here.