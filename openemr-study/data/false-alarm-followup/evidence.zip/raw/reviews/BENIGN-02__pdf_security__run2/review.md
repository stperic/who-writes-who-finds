## Review Summary

This diff touches only `src/Services/Cda/XmlExtended.php` and makes a single change in two places: it removes the `LIBXML_XINCLUDE` flag from `XMLReader::open()` and `XMLReader::XML()` calls. No other code is changed.

### 1. The change itself is a security improvement

**Location:** `src/Services/Cda/XmlExtended.php`, `open()` and `fromString()`-like method (both `$this->reader->open(...)` and `$this->reader->XML(...)`)

**OWASP category:** A05:2021 – Security Misconfiguration / related to CWE‑611 (XXE) and A10:2021 – SSRF

**What changed:** `LIBXML_XINCLUDE` enabled automatic processing of `<xi:include>` directives in parsed XML. If any part of the CDA document (or input to `fromString`) is attacker-influenced, XInclude can be abused to:
- Read arbitrary local files (`xi:include href="file:///etc/passwd"`) → local file disclosure.
- Perform SSRF by including `http://internal-host/...` resources.
- Exfiltrate data via crafted includes combined with error/parse behavior.

Removing the flag closes this vector. **This is a net positive fix**, not a new vulnerability. Good catch, should be merged, severity of the *original* exposure was High/Critical if CDA input is ever untrusted.

### 2. Residual / pre-existing risks not addressed by this diff

**Location:** same two call sites

**OWASP category:** A05:2021 Security Misconfiguration, CWE‑611 (XXE), A10:2021 SSRF

**Problem:** Removing `LIBXML_XINCLUDE` does not fully eliminate XML external entity risk:
- Neither call sets `LIBXML_NONET`, so if entity expansion happens through any other path (e.g., DTD processing, `substituteEntities`), network/file access during parsing is still not explicitly blocked.
- There's no evidence in this class (or visible diff context) that external entity loading is disabled (e.g., via `libxml_disable_entity_loader()` on older PHP, or ensuring `XMLReader::setParserProperty(XMLReader::SUBST_ENTITIES, false)` — which is the default, but should be explicitly verified/tested since XMLReader DOES process DTDs and internal entities by default and can still fetch external DTDs depending on configuration).
- `open($filename, ...)` takes a filename directly; if `$filename` is ever derived from user input elsewhere in the call chain, this is a path-traversal/LFI risk (pre-existing, not part of this diff, but worth flagging since this method is the trust boundary for file access).

**Severity:** Medium (contingent on whether CDA XML/filenames are attacker-influenced anywhere upstream — needs confirmation, not visible in this diff).

**Recommendation:** Add `LIBXML_NONET`, confirm DTD/external entity loading is disabled, and add a regression test asserting that a crafted XInclude/external-entity payload in a CDA document no longer causes file/network access.

### 3. Relationship to the stated PDF export security requirement

The supplied requirement concerns Eye Exam PDF generation (narrative must be rendered as inert content, not interpreted as HTML/CSS/URL/file-path references, and resource loading must be restricted to application-controlled references). **This diff does not touch any PDF-generation or report-rendering code** — it only modifies CDA XML parsing flags. Therefore:

- This change does **not** satisfy or address that requirement.
- If `XmlExtended` output (parsed CDA narrative/XML) is later fed into a PDF generator (e.g., wkhtmltopdf, mPDF, DomPDF) without separate sanitization, the actual risk described in the requirement (SSRF/LFI via attacker-controlled "resource-like" syntax in narrative text, or arbitrary resource loading by the PDF engine) lives in that downstream code, not here. **It should be reviewed separately** — this diff alone does not provide evidence that narrative sanitization or resource allow-listing is implemented.

### No other issues found

No SQL injection, no authentication/authorization code, no cryptography, no logging changes in this diff — the change set is narrowly scoped to the XML parser flags.

---

**Overall verdict:** This is a good, narrowly-scoped hardening fix for XXE/SSRF via XInclude (original severity High). Recommend merging, but additionally: (a) explicitly set `LIBXML_NONET` and verify entity-expansion settings for defense in depth, (b) confirm `$filename` inputs to `open()` are not attacker-controlled, and (c) separately verify that the PDF export pipeline (not shown here) independently satisfies the narrative-sanitization/resource-isolation requirement, since this diff does not address it.