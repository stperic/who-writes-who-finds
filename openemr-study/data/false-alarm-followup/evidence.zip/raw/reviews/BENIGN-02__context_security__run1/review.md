# Security Review

## Diff Analysis (XmlExtended.php)

**Location:** `src/Services/Cda/XmlExtended.php`, lines in `open()` and `XML()` methods

**Change:** Removal of `LIBXML_XINCLUDE` flag from XMLReader initialization in both the file-based `open()` method and the string-based `XML()` method.

**Assessment: This is a positive security fix, not a vulnerability.**

- **OWASP Category:** A05:2021 – Security Misconfiguration / (historically also related to A03:2021 – Injection via XXE)
- **Problem (being fixed):** `LIBXML_XINCLUDE` enables XInclude processing, which allows an XML document to pull in and embed content from other files/URIs referenced via `<xi:include href="...">`. Combined with XML parsing of user-supplied CDA documents, this flag significantly increases the attack surface for:
  - **XXE-adjacent/SSRF attacks** — XInclude can fetch remote or local resources (`href="http://internal-service/..."` or `href="file:///etc/passwd"`), leading to Server-Side Request Forgery or local file disclosure, since CDA documents are often provided by external parties (e.g., received via HIE/health information exchange) and parsed on the server.
  - **Information disclosure** of local files if the parser is allowed to include `file://` resources.
  - This is independent of `libxml_disable_entity_loader`, since XInclude processing is a separate mechanism from general entity expansion and is not blocked by typical entity-loader-disabling mitigations.
- **Severity:** The *removal* is a **fix** for a **High** severity issue (SSRF / Local File Disclosure via XInclude) that existed in the prior code.

This change should be approved and is a good security improvement — it reduces the attack surface for the XML parser used on (likely) untrusted CDA input.

---

## Issues in Code Touched/Relied Upon by This Change

Although not modified by this PR, the following pre-existing issues in files that interact with `XmlExtended`/CDA XML parsing deserve attention since the PR touches the exact parsing configuration that affects them:

### 1. `validateXmlXsd()` – Possible XXE via `DOMDocument::loadXML`
**Location:** `CdaValidateDocuments.php`, `validateXmlXsd()`
```php
$dom = new DomDocument();
$dom->loadXML($document);
```
- **OWASP Category:** A05:2021 – Security Misconfiguration (XXE, CWE-611)
- **Problem:** `DOMDocument::loadXML()` is called without explicitly disabling external entity loading or setting safe flags (e.g., no `LIBXML_NONET`, and depending on PHP version, external entity substitution could be active). While PHP >= 8.0 disables external entity loading by default, if this code runs on any configuration/version where that's not guaranteed, or if `libxml_disable_entity_loader(false)` has been called elsewhere in the request lifecycle, this is vulnerable to XXE (SSRF, local file read, denial of service via billion-laughs if `LIBXML_PARSEHUGE`-like settings are combined elsewhere).
- **Severity:** Medium-High (depends on PHP version/global libxml state; should still explicitly harden with `LIBXML_NONET` and ensure no external entity resolution).

### 2. SSRF Risk in `ettValidateDocumentRequest()` 
**Location:** `CdaValidateDocuments.php`, constructor and `ettValidateDocumentRequest()`
```php
$this->externalValidatorUrl = trim((string) ($GLOBALS['mdht_conformance_server'] ?? null)) ?: '';
...
curl_setopt($ch, CURLOPT_URL, $post_url);
```
- **OWASP Category:** A10:2021 – Server-Side Request Forgery (SSRF)
- **Problem:** The validator URL is taken directly from global configuration (`$GLOBALS['mdht_conformance_server']`) and used as a cURL target without validation (e.g., no allow-list, no restriction against internal/private IP ranges). If this configuration value can be influenced by a lower-privileged admin role or is exposed via a misconfigured settings UI, it enables SSRF. Even if only super-admin configurable, it's worth flagging as a hardening gap — no URL scheme/host validation is performed before making outbound requests with file uploads.
- **Severity:** Low-Medium (requires admin-level config access, but no defense-in-depth validation).

### 3. TLS Certificate Validation Can Be Disabled
**Location:** `CdaValidateDocuments.php`, `ettValidateDocumentRequest()`
```php
$httpVerifySsl = (bool) ($GLOBALS['http_verify_ssl'] ?? true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $httpVerifySsl);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
```
- **OWASP Category:** A02:2021 – Cryptographic Failures
- **Problem:** If `http_verify_ssl` global is set to `false` (a configurable option), TLS certificate validation is disabled entirely for this outbound request containing patient CCDA data (PHI), enabling MITM attacks. This is a known escape hatch elsewhere in OpenEMR, but it's worth flagging given this code sends PHI externally.
- **Severity:** Medium (configuration-dependent, but sends PHI over the connection).

### 4. Insecure Temp File Handling
**Location:** `CdaValidateDocuments.php`, `ettValidateDocumentRequest()`
```php
$post_file = $GLOBALS['temporary_files_dir'] . '/ccda.xml';
file_put_contents($post_file, $xml);
```
- **OWASP Category:** A01:2021 – Broken Access Control / CWE-377 (Insecure Temporary File)
- **Problem:** A static, predictable filename (`ccda.xml`) is used in a shared temp directory for every validation request. This can cause:
  - Race conditions if concurrent requests overwrite each other's PHI data (data integrity issue).
  - Potential symlink attacks if the temp directory has weak permissions and is shared with other processes/users.
  - The file is never deleted after use, potentially leaving PHI (patient CDA/CCDA XML) sitting in a temp directory indefinitely.
- **Severity:** Medium (PHI data leakage/retention risk and race condition).

### 5. Lack of Logging on Validation Failures Involving PHI
**Location:** `ettValidateCcda()` / `ettValidateDocumentRequest()`
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** Errors from the external validator are logged via `SystemLogger` with generic messages, but there's no audit trail tying validation requests (which transmit PHI to an external/configurable host) to a specific user/session. Given PHI is sent to a third-party/configurable endpoint, there should be an audit log entry (similar to HIPAA audit requirements) recording who triggered the export and to where.
- **Severity:** Low-Medium.

### 6. Command Construction in `startValidationService()`
**Location:** `CdaValidateDocuments.php`, `startValidationService()`
```php
$cmd = $system->escapeshellcmd("node " . $path . "/app.js") . $redirect_errors;
...
exec($cmd . " > /dev/null &");
```
- **OWASP Category:** A03:2021 – Injection (OS Command Injection) — mitigated here
- **Problem:** `$path` is derived from `$GLOBALS['fileroot']`, a server-controlled configuration value, not user input, so injection risk is low. However, relying on `escapeshellcmd` (rather than `escapeshellarg` for individual arguments) is a weaker practice and worth noting as a latent code-quality/security concern if `fileroot` or `temporary_files_dir` globals were ever derived from less-trusted input.
- **Severity:** Low (currently not user-reachable, but fragile pattern).

---

## Summary

| # | Location | Category | Severity |
|---|----------|----------|----------|
| - | `XmlExtended.php` diff | A05 Security Misconfiguration (XXE/SSRF via XInclude) | **Fix (improvement)** |
| 1 | `CdaValidateDocuments::validateXmlXsd` | A05 Security Misconfiguration (XXE) | Medium-High |
| 2 | `CdaValidateDocuments::ettValidateDocumentRequest` | A10 SSRF | Low-Medium |
| 3 | `CdaValidateDocuments::ettValidateDocumentRequest` | A02 Cryptographic Failures | Medium |
| 4 | `CdaValidateDocuments::ettValidateDocumentRequest` | A01 Broken Access Control / Insecure temp file | Medium |
| 5 | `CdaValidateDocuments` (overall) | A09 Logging & Monitoring | Low-Medium |
| 6 | `CdaValidateDocuments::startValidationService` | A03 Injection (low risk currently) | Low |

**Recommendation:** The diff itself is a good security fix and should be merged. However, since it touches the XML parsing hardening posture, I recommend also addressing the `DOMDocument::loadXML` XXE hardening (item #1) in the same effort, since it's the same class of vulnerability (XML external resource resolution) in a sibling method of a related class, and fixing one without the other leaves an inconsistent security posture for CDA document handling.