## Review of `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig` change

### Summary of the change
The diff adds a whitelist (`$allowedColumns`) that the sort field must belong to before it is concatenated into the `ORDER BY` clause. Previously, `$search->getField()` was inserted directly into the SQL string with no validation at all.

---

### 1. (Pre-existing, now fixed) SQL Injection via ORDER BY — OWASP A03:2021 Injection
**Location:** `src/Services/Search/SearchConfigClauseBuilder.php`, old version of `buildSortOrderClauseFromConfig`

**Problem:** The old code built the `ORDER BY` clause as:
```php
$clauses[] = $search->getField() . " " . ($search->isAscending() ? "ASC" : "DESC");
```
`$search->getField()` ultimately derives from user-controlled sort parameters (e.g., an API `_sort` query parameter) via `SearchQueryConfig`/`getSearchFieldOrders()`. Because column names cannot be parameterized with prepared statement placeholders, this field was concatenated unsanitized directly into the SQL string — a classic SQL injection (CWE-89) via the `ORDER BY` clause, allowing attackers to inject arbitrary SQL (e.g., `id; DROP TABLE...`, boolean/time-based blind injection via subqueries, etc.) depending on what wraps the query.

**Severity:** High (pre-patch). This appears to be the primary motivation for the patch and is fully addressed by the new whitelist check — **good fix**.

---

### 2. Residual risk: whitelist enforcement is caller-dependent — OWASP A03:2021 Injection / A04:2021 Insecure Design
**Location:** `buildSortOrderClauseFromConfig($config, array $allowedColumns)`

**Problem:** The security guarantee now depends entirely on every caller passing a *safe, hard-coded* `$allowedColumns` array. The method itself does not enforce where this list comes from. In the shown `PatientService::search()`, this is done correctly using a hard-coded `self::ALLOWED_SORT_COLUMNS` constant — good. However:
- This is a **breaking signature change** (new required parameter, no default value). Any other call site in the codebase not shown in this diff/PR will either fail to compile/throw a `TypeError`, or — more dangerously — someone "fixing" the break might pass a dynamically built or overly permissive list (e.g., `array_keys($data)` or all table columns) just to get the code working again, silently re-introducing the injection vulnerability. This should be verified by searching the whole codebase for other callers of this method before merge.
- There's no defense-in-depth (e.g., also restricting to `[a-zA-Z0-9_]+` pattern) in case a future allowed-columns list is built dynamically from a less trustworthy source (e.g., table metadata including a column with unusual name/alias, or a developer error including a user-influenced value in the list).

**Severity:** Medium (design robustness concern, not an exploitable bug in the code shown, but a fragile security control).

---

### 3. Silently dropped invalid sort fields — no logging — OWASP A09:2021 Security Logging & Monitoring Failures
**Location:** `buildSortOrderClauseFromConfig`, `continue;` branch

**Problem:** When a disallowed field is submitted, it is silently ignored (`continue`) rather than logged or surfaced as an error to the caller/user. This is defensible from a usability perspective, but it also means that SQL-injection probing attempts against the `_sort`/order parameters (which is exactly the type of attack this whitelist is defending against) leave no audit trail. Security monitoring would benefit from at least a debug/info-level log entry (without leaking into user-facing error responses) when a request supplies a disallowed sort column, to help detect scanning/attack attempts.

**Severity:** Low.

---

### 4. Un-reviewed dependency: `buildQueryPaginationClause` — OWASP A03:2021 Injection (unverified)
**Location:** `SearchConfigClauseBuilder::buildQueryPaginationClause` (used in `PatientService::search()`, not included in the diff or provided files)

**Problem:** The pagination clause (`LIMIT`/`OFFSET`) is built the same way the `ORDER BY` clause was previously built (string concatenation) based on `$config->getPagination()`. Since this method was not included in the diff/context, it could not be verified whether `limit`/`offset` values are validated as integers / bound as parameters, or whether they're subject to the same class of injection that the `ORDER BY` fix addresses. **Recommend auditing this method as part of the same security review**, since it is structurally analogous to the vulnerability just fixed.

**Severity:** Unknown/Medium — flagged for follow-up review, not confirmed vulnerable.

---

### 5. Minor: whitelist/schema drift — OWASP A04:2021 Insecure Design
**Location:** `PatientService::ALLOWED_SORT_COLUMNS`

**Problem:** Not a vulnerability per se, but the whitelist must be kept in sync with the actual `SELECT`/`JOIN` column list in `search()`. If a column is removed/renamed in the complex multi-table query (or ambiguous between joined tables, e.g. `date`/`id`/`status` could exist in more than one joined table), sorting could either silently fail or throw a SQL error that could leak schema information in a stack trace if `display_errors`/debug mode is misconfigured (tying into OWASP A05:2021 Security Misconfiguration if verbose DB errors are exposed to end users). Ensure error handling around `QueryUtils::sqlStatementThrowException` does not leak raw SQL/DB errors to API consumers.

**Severity:** Low.

---

## Overall Assessment
- The core change is a **solid, well-targeted fix for a real SQL injection vulnerability** (OWASP A03:2021) in the `ORDER BY` clause construction, using a proper allow-list approach with strict (`in_array(..., true)`) comparison.
- No new vulnerabilities are introduced by the diff itself.
- Before merging, verify:
  1. All other call sites of `buildSortOrderClauseFromConfig` across the codebase have been updated to pass a safe, hard-coded allow-list (not a dynamically/user-influenced one).
  2. `SearchConfigClauseBuilder::buildQueryPaginationClause` handles pagination values safely (bound parameters / integer casting), since it wasn't in scope of this diff but sits right next to the fixed code and is invoked from the same `search()` method.
  3. Consider adding a log line when sort fields are rejected, to aid detection of attempted injection/scanning.