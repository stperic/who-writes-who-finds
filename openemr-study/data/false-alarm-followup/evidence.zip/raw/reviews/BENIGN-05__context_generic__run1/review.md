## Review Comments

**Location:** `library/auth.inc.php`, modified timeout block

**Issue 1 — Behavioral change: timeout enforcement now applies to background polling requests**

Previously, when `skip_timeout_reset` was set (used by Messages/Reminders/Flow Board polling scripts), the *entire* block — including the `isSessionExpired()` check — was skipped. That means those background requests never triggered `authCloseSession()` / `authLoginScreen(true)`.

With this change, `isSessionExpired()` is always evaluated regardless of `skip_timeout_reset`; only the *reset* of the expiration timer is skipped. This means a background AJAX polling call can now trigger a forced logout + `authLoginScreen(true)` call mid-request.

This is arguably a correctness fix (the old code allowed a session to be kept "alive" indefinitely via polling while bypassing the actual expiration check, which seems like a security-relevant oversight), but it's also a meaningful behavior change that isn't mentioned in the comment/commit. `authLoginScreen()` typically emits an HTML login form; if it's invoked from inside a background polling endpoint that expects JSON, this could corrupt the response and confuse client-side JS (e.g., throwing parse errors instead of a clean "please log in again" signal).

**Severity:** Medium — likely an intentional/desired fix, but needs verification that all callers of this code path (especially the Messages/Reminders/Flow Board polling endpoints) handle a login-screen response gracefully instead of breaking their AJAX handlers.

---

**Issue 2 — Added DB query on every polling request**

Because `isSessionExpired()` always runs now (even when `skip_timeout_reset` is set), every high-frequency polling request (e.g., Messages/Reminders) will issue a `SELECT` against `session_tracker` that previously was skipped entirely. For busy multi-user installations with frequent polling, this adds additional DB load.

**Severity:** Low — minor performance/scalability consideration, likely acceptable given the correctness benefit, but worth noting in review/testing.

---

Other than these two behavioral implications, the refactor itself is clean, reduces nesting, and the updated comment is accurate and clear.