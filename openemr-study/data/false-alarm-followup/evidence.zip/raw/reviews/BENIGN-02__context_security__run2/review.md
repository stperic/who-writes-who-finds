# Security Review

## Summary of the Diff

The diff removes `LIBXML_XINCLUDE` from two `XMLReader` calls in `XmlExtended.php`. This is a **positive security fix**, not a vulnerability. I'll explain why, then cover related/pre-existing issues in the touched code and surrounding context.

---

### Finding 1 (Positive change — not a vulnerability)
- **Location:** `src/Services/Cda/XmlExtended.php`, both `open()` and `XML()` calls
- **OWASP Category:** A05:2021 – Security Misconfiguration / A03:2021 – Injection (XXE-adjacent)
- **Analysis:** `LIBXML_XINCLUDE` enables automatic processing of `<xi:include>` directives in parsed XML, which can be used to pull in arbitrary local files (local file disclosure) or, if `href` points to a URL/wrapper, to trigger SSRF or further XML entity expansion. Removing this flag reduces attack surface for malicious CDA/XML documents that embed XInclude directives. This is a good hardening change. Note `LIBXML_NOENT`/external entity loading is not enabled here, which is good, but XXE protection should still be explicitly verified (see Finding 2).

**Severity:** N/A (fix, reduces risk previously present — was likely Medium/High before this patch)

---

## Pre-existing / Related Issues in Touched Code

### Finding 2: Possible residual XXE / external entity risk
- **Location:** `src/Services/Cda/XmlExtended.php`, `open()` / `XML()`
- **OWASP Category:** A03:2021 – Injection (XXE) / A05:2021 – Security Misconfiguration
- **Problem:** The code does not explicitly call `libxml_disable_entity_loader(true)` (for older PHP) or verify that `LIBXML_NOENT`/`LIBXML_DTDLOAD` are absent. While modern PHP (8+) disables external entity substitution by default, if this code runs on older PHP/libxml combinations, DOCTYPE-based entity expansion (XXE) could still be possible since `LIBXML_DTDLOAD`/`LIBXML_DTDATTR` are not explicitly suppressed and DTD processing is implicit when loading untrusted XML. CDA documents often originate from external systems and are a classic XXE vector.
- **Severity:** Medium (context-dependent on PHP/libxml version in production)
- **Recommendation:** Explicitly ensure `LIBXML_NONET` is set to block network access during parsing, confirm entity substitution is disabled, and validate/sanitize untrusted XML sources before parsing.

### Finding 3: Missing `LIBXML_NONET`
- **Location:** Same `open()`/`XML()` calls
- **OWASP Category:** A10:2021 – Server-Side Request Forgery (SSRF)
- **Problem:** Neither call sets `LIBXML_NONET`, which disables network access during XML parsing (used for fetching external DTDs, schemas, or entities via network URIs). Combined with any DTD/entity resolution, a malicious CDA document could cause the server to make outbound requests to attacker-controlled URLs (SSRF) or internal services.
- **Severity:** Medium
- **Recommendation:** Add `LIBXML_NONET` to parser flags.

---

## Issues in Related File: `CdaValidateDocuments.php`

### Finding 4: SSRF via configurable validator URL
- **Location:** `ettValidateDocumentRequest()`, `curl_setopt($ch, CURLOPT_URL, $post_url)`
- **OWASP Category:** A10:2021 – Server-Side Request Forgery
- **Problem:** `$post_url` is built from `$GLOBALS['mdht_conformance_server']`, an admin-configurable global. If an attacker can influence this config (e.g., via a separate privilege-escalation or admin-takeover bug) or if this value is not tightly restricted, server-initiated requests to arbitrary hosts are possible. Less severe since it requires admin config access, but worth flagging as a hardening gap — no allow-list/validation of the URL format or target host.
- **Severity:** Low–Medium (requires admin-level config control, but no validation/allow-listing present)

### Finding 5: TLS verification disablable via global config
- **Location:** `$httpVerifySsl = (bool) ($GLOBALS['http_verify_ssl'] ?? true);` then `CURLOPT_SSL_VERIFYPEER`
- **OWASP Category:** A02:2021 – Cryptographic Failures
- **Problem:** SSL peer verification can be globally disabled via configuration, enabling MITM attacks on the external validation request (which sends PHI-containing CDA XML over the network). `CURLOPT_SSL_VERIFYHOST` is hardcoded to `2` (good), but `VERIFYPEER` can be turned off.
- **Severity:** Medium (High if PHI exposure considered, since C-CDA documents contain PHI and are transmitted externally)

### Finding 6: Local, unauthenticated validation service command execution
- **Location:** `startValidationService()`
- **OWASP Category:** A05:2021 – Security Misconfiguration / A08:2021 (process integrity) / A01 Broken Access Control
- **Problem:** Starts a Node.js service bound to `localhost:6662` without authentication. Any local process/user can connect and submit documents for "validation" (which triggers `exec`/process spawning). While bound to localhost reduces exposure, in multi-tenant or shared-hosting environments this is a local privilege boundary issue. Also uses `exec()`/`popen()` to launch external processes — ensure `$path` and arguments aren't influenced by user input (currently looks static, but worth flagging given `escapeshellcmd` usage patterns which can still be subtly wrong, e.g. `escapeshellcmd` instead of `escapeshellarg` for path construction is unusual and may not correctly protect command segments).
- **Severity:** Low (mostly static paths), but flag `escapeshellcmd` misuse as an injection-hardening concern.

### Finding 7: PHI written to predictable temp file
- **Location:** `ettValidateDocumentRequest()`: `$post_file = $GLOBALS['temporary_files_dir'] . '/ccda.xml';`
- **OWASP Category:** A01:2021 – Broken Access Control / A02 – Cryptographic Failures (data at rest) / A09 – Logging failures (sensitive data handling)
- **Problem:** The CDA document (containing PHI) is written to a fixed, predictable filename (`ccda.xml`) in a shared temp directory with no unique naming (e.g., no `tempnam()`/UUID), no explicit permission hardening, and no cleanup (`unlink`) after the request completes. This creates a race condition risk (file could be overwritten/read by concurrent requests or other local users) and leaves PHI residue on disk.
- **Severity:** Medium (PHI exposure risk, plus race condition between concurrent validation requests using the same filename)
- **Recommendation:** Use `tempnam()` with restrictive permissions and delete the file in a `finally` block.

### Finding 8: Information disclosure via error messages
- **Location:** `ettValidateDocumentRequest()` — `xlt('Validation Request failed') . ': Error ' . (curl_error($ch) ...)`
- **OWASP Category:** A09:2021 – Security Logging and Monitoring Failures / A05 Misconfiguration
- **Problem:** Raw cURL error messages (potentially containing internal hostnames/URLs/IPs of the validation server) are stored into `ccdaValidationResults`, which per `createSchematronHtml()` is later rendered into HTML served to users via Twig. If the Twig template doesn't escape this field, or if curl error text includes attacker-influenced data, this could leak internal infrastructure details to end users. Verify the Twig template auto-escapes `description`.
- **Severity:** Low–Medium (depends on template escaping — recommend confirming `cda-validate-results.html.twig` autoescapes).

### Finding 9: No authentication/authorization check visible in this class
- **Location:** `CdaValidateDocuments` class as a whole
- **OWASP Category:** A01:2021 – Broken Access Control
- **Problem:** This class performs no access-control checks itself (likely enforced by a caller), but since it handles PHI documents and can be invoked to make external HTTP requests, it's worth confirming at the controller/route level that only authorized, authenticated users can trigger `validateDocument()`/`ettValidateCcda()`. Flagging as a reminder since it's outside this diff's visibility — not confirmed broken, just unverifiable from provided code.
- **Severity:** Informational (needs verification outside this file)

---

## Overall Assessment

- The diff itself (removal of `LIBXML_XINCLUDE`) is a **security improvement**.
- No new vulnerabilities are introduced by this specific change.
- Several **pre-existing** issues in the XML parsing path (missing `LIBXML_NONET`) and in the related `CdaValidateDocuments.php` (SSRF via configurable URL, disablable TLS verification, predictable temp file with PHI, potential information disclosure) should be tracked and remediated, given this code handles clinical documents containing PHI.