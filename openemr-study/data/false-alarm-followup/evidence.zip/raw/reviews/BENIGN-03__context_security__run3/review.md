## Security Review – `interface/billing/get_claim_file.php`

### 1. Possible broken access control if `denyWithTemplate()` does not terminate execution
**Location:** `interface/billing/get_claim_file.php`, new ACL check block
```php
if (!AclMain::aclCheckCore('acct', 'eob', '', 'write') && !AclMain::aclCheckCore('acct', 'bill', '', 'write')) {
    AccessDeniedHelper::denyWithTemplate("ACL check failed for acct/eob or acct/bill: Billing Manager", xl("Billing Manager"));
}
```
**OWASP Category:** A01:2021 – Broken Access Control
**Problem:** There is no explicit `exit`/`die`/`return` after the call to `AccessDeniedHelper::denyWithTemplate()`. The source of `AccessDeniedHelper` is not included in this review, so it cannot be confirmed that this helper terminates the script internally. If it merely renders a "access denied" template and returns, execution will fall through to the CSRF check and then to the rest of the file, which presumably reads and streams the claim file — completely bypassing the newly added access control. This is a common anti-pattern in PHP applications (print-and-continue instead of print-and-exit).
**Severity:** High (potentially Critical if termination is not guaranteed) — must be verified before merge. Add an explicit `exit;` after the call regardless of the helper's internal behavior, as defense in depth.

---

### 2. Coarse-grained authorization — no per-resource (claim/patient) ownership check
**Location:** New ACL check in `get_claim_file.php` (and the file-retrieval logic further down, not shown in diff)
**OWASP Category:** A01:2021 – Broken Access Control (IDOR)
**Problem:** The new check only validates that the logged-in user has the global `acct/eob` or `acct/bill` **write** permission. It does not appear to validate that the specific claim file being requested (presumably identified by an ID/path in `$_GET`) belongs to a context/encounter the user is actually permitted to access. If the file is selected via a user‑supplied ID, any user with generic billing-write permission could potentially retrieve claim files for patients/encounters they should not have access to (horizontal privilege escalation / IDOR). This should be confirmed against the full file, since it isn't included in the diff, but is a critical consideration for any file-retrieval endpoint gated solely by a role-level ACL.
**Severity:** Medium–High (depends on downstream file-selection logic, which should be reviewed).

---

### 3. CSRF token passed via `$_GET` (pre-existing, but still relevant to this endpoint)
**Location:** `CsrfUtils::verifyCsrfToken($_GET["csrf_token_form"])`
**OWASP Category:** A07:2021 – Identification and Authentication Failures / A05:2021 – Security Misconfiguration
**Problem:** The CSRF token is transmitted in the query string (GET) rather than in a POST body or header. Query-string parameters are far more likely to be logged (web server access logs, proxies, browser history) or leaked via the `Referer` header to third-party resources, increasing the chance that a valid CSRF token is exposed and reused. This is pre-existing code, but since the PR specifically modifies the control flow of this endpoint, it is worth flagging and fixing as part of hardening this file-access path (e.g., migrate to POST and validate via header).
**Severity:** Low–Medium.

---

### 4. No security logging / audit trail for denied access attempts
**Location:** New ACL check block
**OWASP Category:** A09:2021 – Security Logging and Monitoring Failures
**Problem:** When access is denied, no audit log entry (e.g., via OpenEMR's standard `EventAuditLogger`/`newEvent` logging used elsewhere for PHI access) is written. For a billing/PHI-adjacent endpoint, failed authorization attempts to access claim files should be logged for monitoring/intrusion detection purposes, consistent with HIPAA audit requirements and OpenEMR's existing logging conventions elsewhere in the codebase.
**Severity:** Low–Medium.

---

### 5. Permission choice (`write`) may be a functional/design mismatch, not a vulnerability per se
**Location:** New ACL check
**OWASP Category:** A04:2021 – Insecure Design (informational)
**Problem:** The endpoint name `get_claim_file.php` suggests a read/download operation, yet the check requires `write` permission on `acct/eob` or `acct/bill`. This isn't a vulnerability, but it's worth confirming the correct ACL semantics were used (OpenEMR's `write` ACL check actually also implicitly requires `view`-level access per `aclCheckCore`, so this is likely intentional) — flagged only to ensure business logic correctness, not as a direct security flaw.
**Severity:** Informational.

---

### Pre-existing / inherited code concerns (in `AclMain.php`, relied upon by this change)

- **`aclCheckCore()` superuser bypass:** Automatically grants access if the user has `admin/super`. This is intended design, but worth reconfirming that `get_claim_file.php`'s intent (restricting to billing roles) is compatible with the blanket superuser bypass — not a new issue, just inherited trust assumption.
- **`zhAclCheck()` (same file, unrelated to this diff) builds SQL with string concatenation for `IN (...)` placeholders.** Although parameter binding is used correctly (placeholders are filled via bound parameters, not direct string interpolation of values), this pattern is fragile and should be reviewed for correctness/maintainability; no direct injection found since values are parameterized, but it's flagged for awareness since it's adjacent to the ACL code this PR now depends on.

---

## Summary
The intent of this PR (adding an ACL gate to a previously under-protected billing file endpoint) is a good security improvement. However:
- The most critical concern is **verifying that `AccessDeniedHelper::denyWithTemplate()` halts execution**; if not, this patch provides a false sense of security while leaving the endpoint exploitable (A01 - Broken Access Control).
- Secondary concerns involve lack of per-resource authorization checks (IDOR risk), absence of audit logging for denied attempts, and the pre-existing GET-based CSRF token handling.

Recommend: add explicit `exit;` after the denial branch, confirm/add resource-level ownership checks in the file retrieval logic, and add audit logging for denied access attempts before merging.