## Review comments

**`src/PaymentProcessing/Recorder.php` – `getNextSequenceNumber()`**

1. **Minor: generic exception type** – severity: low  
   Throwing a bare `\RuntimeException` makes it hard for callers (e.g. the webhook handler in `RecordPayment::handle()`, which wraps this call in `QueryUtils::inTransaction`) to distinguish "no activity data found" from any other runtime failure. A dedicated exception class (or at least a more specific exception) would make error handling/logging more precise, since this failure will now abort the whole webhook transaction rather than being handled gracefully.

2. **Minor: error message lacks context** – severity: low  
   The exception message `'Could not determine next ar_activity sequence number'` doesn't include `$patientId`/`$encounterId`, which would be useful for debugging when this bubbles up through a transaction failure (especially since the call site in `RecordPayment` has no additional context logging around this call).

3. **Nit: silent truncation risk** – severity: very low  
   `(int) $increment` will silently truncate a non-integer numeric value (e.g. `"3.7"`) rather than treat it as invalid. Given `sequence_no` is expected to be an integer column, this is unlikely in practice, but since the code is already validating defensively, it might be worth also checking `ctype_digit` or verifying there's no fractional part, to avoid masking a data corruption issue.

4. **Note (not a blocker): underlying race condition still unaddressed** – severity: informational  
   The existing comment above the method ("even in a default-configured DB transaction, this still has a potential race condition...") is left unchanged. This PR only hardens the return value/type handling and doesn't address the actual TODO. That's fine as a scoped change, but worth flagging so it isn't forgotten — especially since `RecordPayment::handle()` now relies on this method inside a transaction to generate sequence numbers for multiple activities in a loop, where the race condition is a real concern for concurrent webhook deliveries.

Overall, the change itself (replacing an unchecked value with validated int) is a good, low-risk improvement. The issues above are minor/style-level, not correctness blockers.