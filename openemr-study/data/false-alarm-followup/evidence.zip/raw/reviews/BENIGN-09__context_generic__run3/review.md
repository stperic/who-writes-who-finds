**Location:** `interface/main/calendar/find_group_popup.php` (removed `if (isset($result)) … else … endif` wrapper)

**Issue 1 — Loss of "No groups found" feedback (Correctness / UX regression, Medium)**
The diff removes the entire conditional that distinguished "results found" from "no results"/"no search performed" states. After this change, the `<div id="searchResultsHeader">` table is always rendered unconditionally, and the `xlt("No groups found")` message is gone entirely. Users who search and get zero matches now have no indication that the search returned nothing — they’ll just see an empty table, which is confusing. If this message was relied upon elsewhere (e.g., tested by JS/selectors), that functionality will silently break.

**Issue 2 — Potential undefined variable usage (Correctness / Reliability, Medium)**
Before this patch, the table markup (and whatever loop iterates over `$result` further down, hidden in the diff context) was only rendered when `isset($result)` was true. Now that guard is gone, so if `$searchby`/`$searchparm` aren’t set (e.g., initial page load before any search is submitted), `$result` will be undefined, yet the code that iterates over it (visible just below the removed `else` block) will still execute. This will likely throw a PHP notice/warning (`Undefined variable $result` / `foreach() argument must be of type array|object`) depending on PHP version, which could be displayed to the user if error display is enabled, or at minimum pollute logs.

**Recommendation:**
Keep (or reintroduce) an explicit check — e.g. `if (isset($result) && count($result) > 0)` for the table, and an `else` branch showing "No groups found" (or simply nothing) when `$result` is empty/not set — rather than deleting the conditional outright.

No security concerns identified in this specific diff beyond the above reliability/UX issues.