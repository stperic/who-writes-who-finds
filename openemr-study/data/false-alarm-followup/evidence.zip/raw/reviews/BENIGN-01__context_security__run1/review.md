## Summary

The core change in this diff is a **positive security fix**: it adds a column allow‑list to `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()`, which previously concatenated a caller‑supplied field name directly into a raw `ORDER BY` SQL fragment with no validation at all. That was a classic SQL injection sink (OWASP A03:2021 – Injection) if the field name ever originated from user input (e.g., an API `_sort` parameter). The new code correctly uses a strict (`in_array(..., true)`) whitelist check before allowing a field into the generated SQL, which is the right fix.

That said, there are residual issues and risks worth flagging, both in the diff itself and in the code it touches.

---

### 1. (Fixed, but note the prior vulnerability) SQL Injection via unsanitized ORDER BY field
- **Location:** `src/Services/Search/SearchConfigClauseBuilder.php`, pre-diff version (`buildSortOrderClauseFromConfig`)
- **Category:** A03:2021 – Injection
- **Problem:** The old code did `$search->getField() . " " . (...)` with no validation, directly building SQL. If `getField()` could ever reflect user-controlled input (e.g., a REST API `_sort=` parameter), this was an unauthenticated SQL injection point in ORDER BY. The new diff correctly mitigates this with a hard-coded whitelist (`PatientService::ALLOWED_SORT_COLUMNS`) and strict comparison.
- **Severity:** High (historical) — now mitigated. Flagging for completeness and to confirm the fix is complete across **all** call sites (see #2).

### 2. Insecure Design: whitelist enforcement depends on every caller behaving correctly
- **Location:** `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()` signature change; `PatientService::search()` call site.
- **Category:** A04:2021 – Insecure Design
- **Problem:** The method now takes `$allowedColumns` as a plain `array` parameter rather than deriving/enforcing it internally or via a dedicated value object. This means the SQL-injection protection is only as strong as every caller's discipline — if any other caller (not shown in this diff, and there may be other consumers of this class elsewhere in the codebase) passes an empty allow-list, a dynamically built list, or (worse) a list derived from user input, the protection is silently defeated or bypassed. Making the signature require an explicit array (rather than a required, type-safe allow-list object, or an internal per-config-type whitelist) leaves room for future misuse.
- **Severity:** Medium — needs verification that **all** call sites of `buildSortOrderClauseFromConfig()` across the codebase pass a safe, hard-coded whitelist (the PR only shows `PatientService` doing so correctly).

### 3. Security Logging and Monitoring Failure: invalid/disallowed sort fields are silently dropped
- **Location:** `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()` (`continue;` branch)
- **Category:** A09:2021 – Security Logging and Monitoring Failures
- **Problem:** When a requested sort field is not in the whitelist, it's silently discarded with no logging. Previously, since the code was vulnerable, any attempt to inject via sort parameters would have "succeeded" (bad), but now such attempts fail *silently*. There's no record of the fact that a client tried to sort by a non-whitelisted/potentially malicious field, which would be valuable for detecting active exploitation attempts against this now-patched injection point.
- **Severity:** Low

### 4. Pre-existing: Insecure Deserialization in `PatientService::touchRecentPatientList` / `getRecentPatientList`
- **Location:** `src/Services/PatientService.php`, `touchRecentPatientList()` and `getRecentPatientList()` — `unserialize($row['patients'])`
- **Category:** A08:2021 – Software and Data Integrity Failures (PHP Object Injection risk)
- **Problem:** Data retrieved from the `recent_patients` table is passed through `unserialize()`. While this data is written by the application itself, `unserialize()` of any DB-stored blob is risky if the table can be influenced by another vector (e.g., direct DB access, a future injection bug, or multi-tenant data crossover) — PHP object injection can lead to RCE/gadget chains if an autoloadable class with a dangerous `__wakeup`/`__destruct` exists in the codebase. This should use `json_encode`/`json_decode` instead of PHP serialization. Not introduced by this diff, but it's in a file this PR's change directly feeds into (the sort-order builder is used in the same `search()` pipeline).
- **Severity:** Medium

### 5. Pre-existing / out-of-scope: No visible authorization check in `PatientService::search()/getOne()`
- **Location:** `src/Services/PatientService.php`, `search()`, `getOne()`, `databaseUpdate()`
- **Category:** A01:2021 – Broken Access Control
- **Problem:** These service methods perform no ACL/ownership check themselves (e.g., verifying the current user/role is permitted to view/edit the given patient); they rely entirely on whatever calls them (controllers) to enforce access control. This isn't a flaw introduced by the diff, but since the diff modifies the query-building pipeline used by every patient search/sort request, it's worth re-confirming that the calling controllers (not shown) still enforce patient-level ACL after this change, and that the new `$allowedColumns` parameter isn't inadvertently exposed to a path that bypasses those checks.
- **Severity:** Informational / needs verification (can't confirm without controller code)

---

## Not Found
- No XSS, CSRF, SSRF, hard-coded secrets, outdated-component, or authentication issues were introduced by this diff.
- The diff itself, in isolation, is a solid defensive fix (SQL injection whitelist). The concerns above are about completeness of adoption across the codebase and about pre-existing adjacent code it relies on.