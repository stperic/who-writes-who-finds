## Review comments

**1. Breaking change to a public static API — missing other call‑sites**
*Location:* `SearchConfigClauseBuilder::buildSortOrderClauseFromConfig()` signature change.
*Issue:* `$allowedColumns` is now a **required** parameter. This method is public and static, so any other code in the codebase that currently calls `buildSortOrderClauseFromConfig($config)` (only one call site is shown here, in `PatientService`) will now throw a fatal `ArgumentCountError`. The diff/PR only updates `PatientService`; there's no evidence the rest of the codebase (other search services) was audited/updated.
*Severity:* **High** — could break other services at runtime if any other caller exists. At minimum, this needs a repo-wide grep before merge, or the parameter should be optional (e.g., default to `null` with a documented "allow all" fallback, or explicitly require it with a deprecation path).

**2. Invalid/disallowed sort fields are silently dropped**
*Location:* the new `in_array($field, $allowedColumns, true) { continue; }` branch.
*Issue:* If a caller (e.g., an API consumer) requests `_sort=some_unallowed_field`, the field is silently discarded instead of raising a validation error (400) or being logged. The end user has no indication that their sort request was ignored, and if *all* requested fields are invalid, the query silently falls back to unsorted results. From a security standpoint this is correct (fail closed), but from a usability/debuggability standpoint, this should probably surface an error/warning rather than fail silently.
*Severity:* **Low–Medium** (reliability/UX, not correctness-breaking).

**3. Hard-coded whitelist duplicated from schema, risk of drift**
*Location:* `PatientService::ALLOWED_SORT_COLUMNS`.
*Issue:* The whitelist is a manually maintained array parallel to the `patient_data` schema/service field list (`getFields()` already exists on `BaseService`). If columns are renamed/added/removed in the schema or in `getFields()`, this list can silently drift out of sync, causing legitimate sort fields to be rejected or, worse, if someone copies this pattern elsewhere without care, an allowed list could include a column that no longer exists (producing a SQL error after the whitelist check passes).
*Severity:* **Low–Medium** (maintainability).

**4. Potential column ambiguity for whitelisted names used in multi-join query**
*Location:* `PatientService::search()` — the SQL joins `patient_data`, `patient_history`, `provider`, and `patient_additional_addresses` subqueries; `ALLOWED_SORT_COLUMNS` includes plain, unqualified names like `id`, `date`, `status`.
*Issue:* Allowing unqualified column names in `ORDER BY` for a query with multiple joined subqueries risks "ambiguous column" SQL errors if any joined subquery also exposes a column with the same name (most are aliased here, so it currently seems safe, but this is fragile — a future change to one of the subqueries' SELECT list could silently break sorting by producing a SQL error at runtime rather than a compile-time issue). Columns in the whitelist should ideally be qualified (e.g., `patient_data.id`) to avoid ambiguity regardless of future join changes.
*Severity:* **Medium** (latent correctness/reliability risk).

**5. Minor: future copyright year**
*Location:* file header, `@copyright Copyright (c) 2026 OpenCoreEMR Inc`.
*Issue:* Likely a typo (should probably be the current year, not 2026), unless intentional.
*Severity:* **Trivial/Nit**.

**6. No test coverage shown for the new whitelist behavior**
*Issue:* This is a security-relevant change (preventing SQL injection via sort field), but no unit test is included in the diff verifying that disallowed fields are filtered out and that allowed fields still produce correct `ORDER BY` clauses.
*Severity:* **Low** (should add tests, especially since this closes an injection vector).

Overall, the core idea (introducing a column whitelist to prevent SQL injection through the `ORDER BY` clause) is a good and necessary fix. The main actionable concerns are verifying all callers were updated for the new required parameter (#1) and qualifying/validating the whitelist against the actual joined query shape (#3, #4).