## Review of `library/auth.inc.php` diff

### 1. (Fixed by this diff) Session-timeout bypass via client-controlled parameter
- **Location:** Pre-change code (the removed `if (empty($skipSessionExpirationCheck) && empty($_REQUEST['skip_timeout_reset']))` block)
- **OWASP Category:** A07:2021 – Identification and Authentication Failures (also relevant to A04 – Insecure Design)
- **Problem:** In the old logic, when `$_REQUEST['skip_timeout_reset']` was non-empty, the **entire** block — including the `SessionTracker::isSessionExpired()` check — was skipped. Since `skip_timeout_reset` is read from `$_REQUEST` (attacker/client controllable, including via query string), any request that appended `?skip_timeout_reset=1` would never be evaluated for expiration, effectively letting a client suppress forced logout on an already-expired session indefinitely. This defeats the idle-session-timeout control.
- **Severity:** Medium–High (pre-existing; this diff resolves it)
- **Note:** The new code correctly separates the two concerns — it always evaluates `isSessionExpired()` first, and only uses `skip_timeout_reset` to decide whether to *extend* the timer. This is a legitimate security improvement and closes the bypass.

### 2. Residual design weakness: client-supplied flag still drives security-relevant logic
- **Location:** New code, `elseif (empty($_REQUEST['skip_timeout_reset']))`
- **OWASP Category:** A04:2021 – Insecure Design
- **Problem:** The decision of whether to refresh the session-expiration timer still depends on an unauthenticated, client-supplied `$_REQUEST` value with no server-side allow-list of which endpoints are permitted to use it (e.g., restricting to known polling endpoints such as Messages/Reminders/Flow Board). While the impact is now limited (it can only prevent *extension* of a session, not bypass *expiration* enforcement), relying on a freely settable request parameter for trust decisions is fragile and could be a footgun if future logic changes reintroduce coupling with the expiration check.
- **Severity:** Low (defense-in-depth concern, not currently exploitable for privilege escalation)
- **Suggestion:** Validate the caller/endpoint (e.g., via a signed token, specific route, or session-stored flag) rather than trusting a raw request parameter.

### 3. General observations
- The `EventAuditLogger` call for the timeout event is preserved, so audit logging for forced logouts continues to function correctly (A09 – Security Logging and Monitoring Failures: no regression).
- No SQL injection, XSS, SSRF, cryptographic, or component-vulnerability issues are introduced by this diff — the change is confined to session-timeout control flow and does not handle user input beyond the existing `$_REQUEST` check, nor does it touch output rendering or external requests.
- This diff is unrelated to the PDF export feature described in the requirement; no issues found there since no PDF-handling code is present in this diff.

### Summary
This diff is primarily a **security fix**: it closes an authentication/session-management bypass where a request parameter could suppress forced logout of expired sessions. One minor residual design concern remains (client-controlled flag for extending session), rated low severity. No new vulnerabilities were introduced by this change.