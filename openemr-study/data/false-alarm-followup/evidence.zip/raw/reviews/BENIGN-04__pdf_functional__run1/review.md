## Review of `portal/portal_payment.php` diff

### 1. (Fixed, but verify) Reflected/DOM-based XSS via inline `<script>` block
**Location:** `portal/portal_payment.php`, line ~90 (the `echo "<script>..."` line)
**OWASP Category:** A03:2021 – Injection (XSS)
**Before:** `$edata['table_args']` and `$edata['checksum']` were concatenated directly inside a single‑quoted JS string with no escaping. If either value (decrypted/stored data) contains a `'`, `</script>`, or other JS‑breaking characters, an attacker could break out of the string literal and inject arbitrary script — classic XSS.
**After:** The values are now passed through `js_escape()`. This is the right direction, **but the security of the fix depends entirely on the implementation of `js_escape()`**, which is not included in this diff. Things to verify:
- Does it properly escape all characters that are dangerous in a JS string context (quotes, backslash, newlines, `<`, `>`, `/`)?
- Does it prevent the `</script>` closing-tag injection (i.e., escape `/` or `<`)?
- Is it using something robust like `json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)` rather than a hand-rolled replace?
- Is it applied consistently everywhere similar data is echoed into `<script>` blocks elsewhere in the codebase?

**Severity:** High if `js_escape()` is incomplete/custom and doesn't cover all injection vectors; otherwise this specific line is resolved. **Needs code review of `js_escape()` before sign-off.**

---

### 2. Design concern: untrusted/sensitive data still echoed into inline `<script>`
**Location:** Same line
**OWASP Category:** A05:2021 – Security Misconfiguration (CSP) / A04:2021 – Insecure Design
**Problem:** Even with proper escaping, embedding decrypted payment-related data (`checksum`, `table_args`) directly into an inline `<script>` block:
- Prevents use of a strict Content-Security-Policy (`script-src 'self'` without `'unsafe-inline'`), which is a standard defense-in-depth control against XSS.
- Increases the chance that a future change reintroduces an injection bug, since inline script concatenation patterns are inherently fragile.

**Recommendation:** Pass data to the client via a `<script type="application/json">` tag or a `data-*` attribute, then parse with `JSON.parse()` in an external JS file. This removes the need for string escaping into JS syntax altogether.
**Severity:** Medium (defense-in-depth gap, not an immediate exploit).

---

### 3. Pre-existing / out-of-diff concerns (code this change touches or relies on)

- **Decryption without integrity/authenticity check** — `cryptoGen->decryptStandard($edata['checksum'])` is used to produce `$ccdata`, which appears to hold payment-related data (checksum/cc data naming suggests card or billing info). If `decryptStandard` doesn't also verify an HMAC/AEAD tag, this is a potential **A02:2021 – Cryptographic Failures** issue (no authenticated encryption → tampering/padding-oracle risk). Not addressed by this diff but relevant to the code path.
- **No visible access control check** in the shown snippet (`$edata` is fetched/used without any visible authorization check for the current portal user). If `portal_payment.php` doesn't verify that the logged-in portal user owns the `$edata` record being rendered, this is **A01:2021 – Broken Access Control** (IDOR). Recommend confirming that a prior line (not shown in diff) validates ownership/session binding before this point.
- **Sensitive data in client-side JS** — Regardless of escaping, pushing checksum/payment data into the DOM/JS global scope increases exposure to any other XSS on the page (e.g., via browser extensions, other reflected params) and to logging/analytics scripts that may scrape `window` variables. Consider whether this data needs to be client-side at all, and whether PCI-DSS/PII handling requirements apply here (payment context).
- **No logging** of this data-rendering path is evident — if this page handles payment data, failures (e.g., decryption failure, malformed `table_args`) should be logged per **A09:2021 – Security Logging and Monitoring Failures**, for fraud/audit purposes. Not addressed here.

---

### Relation to the PDF export requirement
This diff and the referenced Eye Exam PDF export requirement are unrelated — nothing in this change touches PDF generation, narrative storage, or image embedding. No PDF-specific issues to report from this diff. If a related PR implements the PDF export feature, it should be reviewed separately for:
- Path traversal / SSRF when fetching report images (A10:2021).
- Access control on which users can export which patient's report (A01:2021).
- XSS in PDF generation if using an HTML-to-PDF renderer that executes JS (if the same unescaped-echo pattern is reused there, it could be far more severe since some PDF renderers execute arbitrary JS/HTML).

---

### Summary Table

| # | Location | OWASP Category | Issue | Severity |
|---|----------|-----------------|-------|----------|
| 1 | `portal_payment.php` inline `<script>` | A03 Injection (XSS) | Fix depends on unverified `js_escape()` implementation | High (pending verification) |
| 2 | Same line | A05 Security Misconfiguration / A04 Insecure Design | Sensitive data still embedded in inline script, blocking strict CSP | Medium |
| 3 | `cryptoGen->decryptStandard()` (pre-existing) | A02 Cryptographic Failures | Possible lack of authenticated encryption on payment checksum data | Medium–High (needs confirmation) |
| 4 | `$edata` retrieval (pre-existing, not shown) | A01 Broken Access Control | No visible ownership/authorization check before rendering payment data | High (needs confirmation) |
| 5 | Overall page | A09 Logging & Monitoring | No evident audit logging around payment data decryption/display | Low–Medium |

**Action required before merge:** Confirm the implementation of `js_escape()` is a robust, context-correct JS-string/JSON escaper (ideally `json_encode` with hex flags), and confirm that access control to `$edata` is enforced earlier in the request.